package learnKotlin

// Function
// Function Type (Int, Int) -> Int
fun sum1(a: Int, b: Int) : Int {
	return a + b
}

// Function Expression
// Function Expression Type (Int, Int) -> Int
fun sum2(a: Int, b: Int) = a + b

fun playWithSum() {
	val a = 100
	val b = 200
	var result: Int

	// What Is Type of something
	//  Type of something is (Int, Int) -> Int
	var something = ::sum1 // Assigning Function Reference
	result = something(a, b)
	println("Result : $result")

	something = ::sum2 	// Assigning Function Expression Reference
	result = something(a, b)
	println("Result : $result")
}

fun playWithLamdbaExpression1() {
	val a = 100
	val b = 200
	var result: Int

	// Lambda Expression
	// 		Are Also Called Anonmous Functions: Functions Without Names
	// Lamdba Expression of Type (Int, Int) -> Int
	// Lambda Expression Start With Curly Brace { and Ends With Curly Brace }
	var something = { x: Int, y: Int -> Int
						x + y
					}

	result = something(a, b)
	println("Result : $result")

	// Lamdba Expression of Type (Int, Int) -> Int
	//		Return Type is Implicit
	something = { x: Int, y: Int ->  x + y }
	result = something(a, b)
	println("Result : $result")
}

fun playWithLamdbaExpression2() {
	val a = 200
	val b = 100
	var result: Int
	var doSomething: (Int, Int) -> Int

			  		// Lambda Expression Having Type (Int, Int) -> Int
	doSomething = { x: Int, y: Int -> x + y } // Lambda To Do Addition
	result = doSomething(a, b)
	println("Result : $result")

					// Lambda Expression Having Type (Int, Int) -> Int
	doSomething = { x: Int, y: Int -> x - y } // Lambda To Do Substraction
	result = doSomething(a, b)
	println("Result : $result")

					// Lambda Expression Having Type (Int, Int) -> Int
	doSomething = { x: Int, y: Int -> x * y } // Lambda To Do Multiplication
	result = doSomething(a, b)
	println("Result : $result")

					// Lambda Expression Having Type (Int, Int) -> Int
	doSomething = { x: Int, y: Int -> x / y } // Lambda To Do Division
	result = doSomething(a, b)
	println("Result : $result")
}

fun main() {
	println("\nFunction: playWithSum")
	playWithSum()

	println("\nFunction: playWithLamdbaExpression1")
	playWithLamdbaExpression1()

	println("\nFunction: playWithLamdbaExpression2")
	playWithLamdbaExpression2()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}