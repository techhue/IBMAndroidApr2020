package learnKotlin

// KOTLIN USES JAVA COLLECTIONS WITH Its Kotlin Style API
fun creatingCollectionsInKotlin() {
	val set = hashSetOf(1, 7, 53)
	// class java.util.HashSet
	println(set)

	val list = arrayListOf("Ding", "Dong", "King", "Kong")
	// class java.util.ArrayList
	println(list)

	val map = hashMapOf(1 to "One", 7 to "Seven", 50 to "Fifty", 10 to "Ten")
	// class java.util.HashMap
	println(map)

	println("\nType of The Kotlin Collections")
	println(set.javaClass)
	println(list.javaClass)
	println(map.javaClass)
}

fun printAll(strings: Collection<String> ) {
	for (string in strings) {
		println("$string")
	}
	println()
}

fun playWithKotlinCollections() {
	val stringList = listOf("One", "Two", "Three", "Four", "One", "Two")
	
	println(stringList.javaClass)
	println("listOf Items")
	printAll(stringList)
	
	val stringSet = setOf("One", "Two", "Three", "Four", "One", "Two")
	println(stringSet.javaClass)
	println("setOf Items")
	printAll(stringSet)
}

class Person(val name: String, var age: Int)

fun playWithKotlinList() {

	// listOf Creates IMMUTABLE LIST	
	// List stores elements in a specified order.
	// Provides indexed access to them. 
	//		Indices start from zero – the index of the first element – and 
	// 		go to lastIndex which is the (list.size - 1).

	// val numbers = listOf<String>("one", "two", "three", "four")
	val numbers = listOf("one", "two", "three", "four")
	println("Number of elements: ${numbers.size}")
	println("Third element: ${numbers.get(2)}")
	println("Fourth element: ${numbers[3]}")
	println("Index of element \"two\" ${numbers.indexOf("two")}")

	// List elements (including nulls) can duplicate: 
	// 	a list can contain any number of equal objects 
	//	or occurrences of a single object

	val bob = Person("Bob", 31)
	val people1 = listOf<Person>(Person("Adam", 20), bob, bob)
	val people2 = listOf<Person>(Person("Adam", 20), Person("Bob", 31), bob)
	// print(people)
	// print(people2)
	println("People 1")
	for (person in people1) {
		println(person.name)
		println(person.age)
	}

	println("People 2")
	for (person in people2) {
		println(person.name)
		println(person.age)
	}

	// mutableListOf Creates MUTABLE LIST

	// MutableList is a List with list-specific write operations.
	// 	for example, to add or remove an element at a specific position.

	val mutableNumbers = mutableListOf(1, 2, 3, 4)
	println(mutableNumbers)
	mutableNumbers.add(5)
	println(mutableNumbers)

	mutableNumbers.removeAt(1)
	println(mutableNumbers)

	mutableNumbers[0] = 0
	println(mutableNumbers)

	mutableNumbers.shuffle()
	println(mutableNumbers)

	// 	As you see, in some aspects lists are very similar to arrays. However, there is one important difference: an array's size is defined upon initialization and is never changed; in turn, a list doesn't have a predefined size; a list's size can be changed as a result of write operations: adding, updating, or removing elements.

	// In Kotlin, the default implementation of List is ArrayList which you can think of as a resizable array.
}

fun playWithSets() {
	// Set stores unique elements; their order is generally undefined. 
	// 		null elements are unique as well: a Set can contain only one null. // Two sets are equal if they have the same size, and 
	//	for each element of a set there is an equal element in the other set.

	val numbers = setOf(1, 2, 3, 4)
	println(numbers)
	
	println("Number of elements: ${numbers.size}")

	// Membership Test
	if ( 1 in numbers ) println("1 is in the set")
	if (numbers.contains(1)) println("1 is in the set")
	
	val numbersBackwards = setOf(4, 3, 2, 1)
	println(numbersBackwards)
	println("The sets are equal: ${numbers == numbersBackwards}")

	// LinkedHashSet is the default implementation
	println(numbers.javaClass)
	
	//	The default implementation of Set – LinkedHashSet 
	//	– preserves the order of elements insertion. 
	// Hence, the functions that rely on the order, 
	//	such as first() or last(), return predictable results on such sets.
	
	println(numbers.first() == numbersBackwards.first())
	println(numbers.first() == numbersBackwards.last())

	// An alternative implementation – HashSet 
	//	– says nothing about the elements order, 
	//	so calling first() or last() functions on it 
	//		returns unpredictable results
}

fun playWithMaps() {
	 // A Map stores key-value pairs (or entries); 
	 //		keys are unique, but different keys can be paired 
	 //		with equal values. 
	 // The Map interface provides specific functions, 
	 //	 such as access to value by key, searching keys and values, and so on.

	// IMMUTABLE MAPS
	// Map<String, Int>
	val numbersMap0 = mapOf("key1" to 1, "key2" to 2, "key3" to 3, "key4" to 1)
	println("\nElements Of numbersMap0")
	println(numbersMap0)
	println("All keys: ${numbersMap0.keys}")
	println("All values: ${numbersMap0.values}")
	
	if ("key2" in numbersMap0) {
		println("Value by key \"key2\": ${numbersMap0["key2"]}")    
	} else {
		println("key2 doesn't exits in map")
	}

	// Membership Test
	if (1 in numbersMap0.values) println("The value 1 is in the map")
	if (numbersMap0.containsValue(1)) println("The value 1 is in the map") 

	// NOTE : 
	// Two maps containing the equal pairs are equal regardless of the pair order.	

	val numbersMap1 = mapOf("key1" to 1, "key2" to 2, "key3" to 3, "key4" to 1)    
	val anotherMap2 = mapOf("key2" to 2, "key1" to 1, "key4" to 1, "key3" to 3)
	println("\nElements Of numbersMap1)")
	println(numbersMap1)

	println("\nElements Of anotherMap2")
	println(anotherMap2)

	println("The maps are equal: ${numbersMap1 == anotherMap2}")

	// MutableMap is a Map with map write operations, 
	// for example, you can add a new key-value pair 
	// or update the value associated with the given key.

	// MUTABLE MAPS
	val numbersMapMutable = mutableMapOf("one" to 1, "two" to 2)
	
	println("\nElements Of numbersMapMutable")
	println(numbersMapMutable)
	numbersMapMutable.put("three", 3)
	println(numbersMapMutable)
	numbersMapMutable["one"] = 11
	println(numbersMapMutable)

	// The default implementation of Map – LinkedHashMap – preserves the order of elements insertion when iterating the map. In turn, an alternative implementation – HashMap – says nothing about the elements order.
}


fun main() {
	println("\nFunction: creatingCollectionsInKotlin")
	creatingCollectionsInKotlin()

	println("\nFunction: playWithKotlinCollections")
	playWithKotlinCollections()

	println("\nFunction: playWithKotlinList")
	playWithKotlinList()

	println("\nFunction: playWithSets")
	playWithSets()

	println("\nFunction: playWithMaps")
	playWithMaps()

	// println("\nFunction: ")
	// println("\nFunction: ")
}