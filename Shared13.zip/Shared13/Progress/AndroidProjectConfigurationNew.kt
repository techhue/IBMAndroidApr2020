

_____________________________________________________
ANDROID PROJECT CONFIGURATION
_____________________________________________________

2. Android Project Directory Structure
.
├── Project.03.01.ManifestAndResources // Android Project
├── app 				// app is Module In Android Studio and Can Consist of Multiple Modules
│   ├── build.gradle 	// Module Level : Gradle Build System File
		_______________________________________________________
				
			android {
			    compileSdkVersion 29 			//<<<<<<<<<
			    buildToolsVersion "29.0.3"		//<<<<<<<<<

			    defaultConfig {
			        applicationId "com.helloworldnew"
			        minSdkVersion 27			//<<<<<<<<<
			        targetSdkVersion 29			//<<<<<<<<<
			        versionCode 1
			        versionName "1.0"

			        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
			    }

			    buildTypes {
			        release {
			            minifyEnabled false
			            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
			        }
			    }

			}

		_______________________________________________________

│   └── src 			// src Directory Contains Source Code Of Project
		└── main
		    ├── AndroidManifest.xml // Android Application Declaration and Configuration
		    ├── assets 
		    ├── java  	// Java and Kotlin Source Code
		    │   └── com
		    └── res 	// Resource Directory Contains Images, Sound Files, Constants etc.
		        ├── drawable-hdpi // Images
		        ├── drawable-ldpi
		        ├── drawable-mdpi
		        ├── layout. // UI Layout .xml Files
		        ├── menu 	// UI Layout .xml Files For Menues
		        └── values  // Constants Declared In Your Andorid App

├── build.gradle 		// Project Level : Gradle Build System File
	_______________________________________________________	
	
		buildscript {
		    ext.kotlin_version = '1.3.72'		//<<<<<<<<< either 1.3.71
		    repositories {
		        google()						//<<<<<<<<<
		        jcenter()						//<<<<<<<<<
		        
		    }
		    dependencies {								//vvvvv	
		        classpath 'com.android.tools.build:gradle:3.6.3' 		//<<<<<<<<<
		        classpath "org.jetbrains.kotlin:kotlin-gradle-plugin:$kotlin_version"

		        // NOTE: Do not place your application dependencies here; they belong
		        // in the individual module build.gradle files
		    }
		}

		allprojects {
		    repositories {
		        google()						//<<<<<<<<<
		        jcenter()						//<<<<<<<<<
		        
		    }
		}

		task clean(type: Delete) {
		    delete rootProject.buildDir
		}

	_______________________________________________________

├── gradle 				// Contains Configuration Related To Gradle Build Systems
│   └── wrapper
		└── gradle-wrapper.properties
		_______________________________________________________

		#Tue May 26 17:08:04 IST 2020
		distributionBase=GRADLE_USER_HOME
		distributionPath=wrapper/dists
		zipStoreBase=GRADLE_USER_HOME
		zipStorePath=wrapper/dists 										  vvvvvvvvv
		distributionUrl=https\://services.gradle.org/distributions/gradle-5.6.4-all.zip  <<<<<<<
		_______________________________________________________

├── gradlew
├── gradlew.bat
├── import-summary.txt
├── local.properties
├── projectFilesBackup
└── settings.gradle


