Type In Kotlin
_______________________________________________________
	1. Type Inferencing 
			Implicitly is Default
			Can Specify Explicitly Also
	2. Type Binding
	3. Value Storage

	// Compiler Will Try To Inference Type : Kotlin Style
	// 		If Not Specified Explicitly
	// Type In Kotlin
	// _______________________________________________________
	// 	1. Type Inferencing 
	// 			Implicitly is Default
	// 			Can Specify Explicitly Also
	// 	2. Type Binding
	// 	3. Value Storage

	val some 	= 10  			// Type : 

	// Explicit Types Assigned
	// Java/C/C++ Style

	val some1: Int 			= 10  			

	e.g.
	val ding3: Float 	= 90.10F
	// 	1. Type Inferenced Will Be Double
	// 	2. Type Binding Done Explicitly Float
	//	3. Value Storage In ding3
	
	// NOTE: In case Java/C/C++ 
		// Type Converstion of Value From Double To Float Will Happen
			// float ding3 	= 90.10

Nullability and NonNullability
_______________________________________________________
	In Kotlin By Default
		Types Are NonNullable
			You CANN'T Assign Null Value To Variables

	In Java/C/C++ By Default
		Types Are Nullable
			You CAN Assign Null Value To Variables

	Kotlin Style
		Design Towards Non-Nullability Rather Towards Nullability

Kotlin Classes Vs Java Classes
_______________________________________________________

// Person Class With Two Properties [Name and isMarried]
	// val means Immutable: name is Constant
	// var means Variable: isMarried can be changed

// In Kotlin: Person Class
// 		It will Generate Constructor with 2 Arugments
//		It will Generate Instance Members for name and isMarried
//		It will Generate Getter and Setters for name and isMarried

class Person(val name: String, var isMarried: Boolean)

// In Java: Person Class
// class Person {
//     private String name;
//     private Boolean isMarried;
    
// // Define Constructor and Constructor Body
//     public Person(String name,Boolean isMarried) {
//         this.name=name;
//         this.isMarried=isMarried;
//     }

// // Getter and Setters 
//     public String getName() {
//     	return name;
//     }

// 	public void setName(String name ) {
// 		this.name = name;
// 	}

// 	public Boolean getIsMarried() {
// 		return isMarried;
// 	}

// 	public void setIsMarried(Boolean isMarried) {
// 		this.isMarried = isMarried
// 	}
// }

fun playWithPersonProperties() {
	// Created person Object of Type Person
	val person = Person("Rajnikant", true)
	// Accessing Person Properties
	
	// Kotlin Compiler Will Generate Setter For MUTABLE Property
		// person.isMarried = false will be converted to
		//		person.setIsMarried(false)
	
	person.isMarried = false

	// Kotlin Compiler Will NOT Generate Setter For IMMUTABLE Property
	// person.name = "Kamal Hassan" // Error: Unmodifiable


	// Kotlin Compiler Will Generate Getters For 
	// 		Both MUTABLE and IMMUTABLE Properties

	// person.name  will get converted into person.getName()
	// person.isMarried will get converted into person.getIsMarried()

	println(person.name)
	println(person.isMarried)
}

// DO EXERCISE
//_____________________________________________________
// Write Person Class In Java
//		Person Has Two Properties Name and isMarried
//		And Able To Do All Above Functionality
// Run Java Code In Online Compiler
//	20 Mintutes I am giving
//_____________________________________________________



// public World {
// 	public static void main(String[] args) {
//         Person ob = new Person("Chinmaye", false);
        
//         System.out.println(ob.name);
//         System.out.println(ob.isMarried);
//     }
// }

_____________________________________________________

ANDROID ENVIRONMENT CONFIGURATION
_____________________________________________________

	Download Android Studio
	_______________________________________________________
		1. Download Andorid Studio Link
			https://developer.android.com/studio
		2.1 Download Android Studio [Windows 64 Bit]
			 Download File: 
				android-studio-ide-192.6392135-windows.zip
				770 MB
		2.2 Unzip Following File
				android-studio-ide-192.6392135-windows.zip

		2.3 Create Hello World Program

_____________________________________________________

ANDROID PROJECT STRCUTURE
_____________________________________________________
1. Open Following Project in Visual Studio Code
	Android.Code1 > Project.03 > Project.03.01.ManifestAndResources
	
2. Android Project Directory Structure
.
├── Project.03.01.ManifestAndResources // Android Project
├── app 				// app is Module In Android Studio and Can Consist of Multiple Modules
│   ├── app.iml 		// App Configuration File: NOT TO BE MODIFIED
│   ├── build 			// [Auto Generated When You Compile Code]
│   ├── build.gradle 	// Module Level : Gradle Build System File
│   └── src 			// src Directory Contains Source Code Of Project
		└── main
		    ├── AndroidManifest.xml // Android Application : Declaration and Configuration
		    ├── assets 
		    ├── java  	// Java and Kotlin Source Code
		    │   └── com
		    └── res 	// Resource Directory Contains Images, Sound Files, Constants etc.
		        ├── drawable-hdpi // Images
		        ├── drawable-ldpi
		        ├── drawable-mdpi
		        ├── layout. // UI Layout .xml Files
		        ├── menu 	// UI Layout .xml Files For Menues
		        └── values  // Constants Declared In Your Andorid App
├── build.gradle 		// Project Level : Gradle Build System File
├── gradle 				// Contains Configuration Related To Gradle Build Systems
│   └── wrapper
├── gradlew
├── gradlew.bat
├── import-summary.txt
├── local.properties
├── projectFilesBackup
└── settings.gradle

_____________________________________________________

CREATING ANDROID PROJECT : HelloWorld
_____________________________________________________

1. Start A New Android Project
2. Select Project Template
	Empty Activity
	Next
3. Fill Required Details
	Name 		 : HelloWorld
	Package Name : com.helloworld
	Save Location: Give Your Directory Path Where You Want To Save Project
	Language	 : Kotlin
	Minimum SDK Version: API 27 Android 8.1
4. Click Finish
5. Wait For Build To Successful
		Build Tab Will Show Build Status

_____________________________________________________

CREATE ANDROID VIRTUAL DEVICE [AVD]
_____________________________________________________
1. Open Tools > AVD Manager
2. Android Virtual Device Manager Window
	Create Virtual Device
		Select Hardware Window
			Category > Phone
				Pixel 3
			Next 
		System Image Window
			X86 Images Tab
				Select 
					Pie | API Level 28 | ABI x86_64 | Android 9.0
					OR 
					Select Whatever Latest API Level You Have
				Next 	
		Android Virtual Device Window
			AVD Name
				Pixel3_API28_IBM
			Finish
3. Android Virtual Device Manager Window
		Launch Android Virtual Device
			Pixel3_API28_IBM
			Click Green Button
		It Will Launch AVD i.e. Android Emulator

_____________________________________________________

RUNNING ANDROID PROJECT : HelloWorld Project
_____________________________________________________
1. Launch AVD i.e. Android Emulator
2. Run > Run 'app'


____________________________________________________________________________

EXISTING ANDROID PROJECT:  OPENING AND UPDATING CONFIGURATION
____________________________________________________________________________
1. Open Following Project In Android Studio
		File > Open > Android.Code1 > Project.03 > Project.03.01.ManifestAndResources
	
2. Update Following Files With Your Configuration
		build.gradle 				// Module Level
		build.gradle 				// Project Level
		gradle-wrapper.properties 	// Gradle Wrapper File	

3. Sync Configuration

4. Clean Project
		Build > Clean Project

5. Run 'app'
	Android App Runs On Android Run Time [ART] similar to JVM
		Android App After Compilation is Byte Code

____________________________________________________________________________

ANDROID PROJECT EXPLORATION
____________________________________________________________________________

	Explore Following Code Examples
		app > src > main
			*.java
			AndroidManifest.xml File
			res
				All *.xml files

	Android.Code1 > Project03
		Project.03.01.ManifestAndResources
		Project.03.02.Snippets
		Project.03.03.ConfigChanges
		Project.03.04.Activities

____________________________________________________________________________

ANDROID CONCEPTS AND DESIGN
____________________________________________________________________________

	0. AndroidManifest.xml Declares Android Application
	1. Android Application Consists of Set of Components
		First Android Application Context/Instance Created
			Then Components Context/Intstance Get Created
		
		Four Kinds Of Android Components
			Activity, Broadcast Reciever, Service and Content Provider

		e.g.  Following Android Application Consists of One Component
					Component is Activity i.e. Activity is Declared
					Activity Name is MainActivity

		    <application
		        android:allowBackup="true"
		        android:icon="@mipmap/ic_launcher"
		        android:label="@string/app_name"
		        android:roundIcon="@mipmap/ic_launcher_round"
		        android:supportsRtl="true"
		        android:theme="@style/AppTheme">
		        
		        <activity android:name=".MainActivity">
		            <intent-filter>
		                <action android:name="android.intent.action.MAIN" />

		                <category android:name="android.intent.category.LAUNCHER" />
		            </intent-filter>
		        </activity>
		    
		    </application>

	2. Definition of Android Activity is Defined Either In .java/.kt File
		Activity Compoent Shows Screen Full UI

			class MainActivity : AppCompatActivity() {

			}







