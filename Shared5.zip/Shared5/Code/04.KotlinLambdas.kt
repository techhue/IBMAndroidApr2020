package learnKotlin

// Function
// Function Type (Int, Int) -> Int
fun sum1(a: Int, b: Int) : Int {
	return a + b
}

// Function Expression
// Function Expression Type (Int, Int) -> Int
fun sum2(a: Int, b: Int) = a + b

fun playWithSum() {
	val a = 100
	val b = 200
	var result: Int

	// What Is Type of something
	//  Type of something is (Int, Int) -> Int
	var something = ::sum1 // Assigning Function Reference
	result = something(a, b)
	println("Result : $result")

	something = ::sum2 	// Assigning Function Expression Reference
	result = something(a, b)
	println("Result : $result")
}

fun playWithLamdbaExpression1() {
	val a = 100
	val b = 200
	var result: Int

	// Lambda Expression
	// 		Are Also Called Anonmous Functions: Functions Without Names
	// Lamdba Expression of Type (Int, Int) -> Int
	// Lambda Expression Start With Curly Brace { and Ends With Curly Brace }
	var something = { x: Int, y: Int -> Int
						x + y
					}

	result = something(a, b)
	println("Result : $result")

	// Lamdba Expression of Type (Int, Int) -> Int
	//		Return Type is Implicit
	something = { x: Int, y: Int ->  x + y }
	result = something(a, b)
	println("Result : $result")
}

fun playWithLamdbaExpression2() {
	val a = 200
	val b = 100
	var result: Int
	var doSomething: (Int, Int) -> Int

			  		// Lambda Expression Having Type (Int, Int) -> Int
	doSomething = { x: Int, y: Int -> x + y } // Lambda To Do Addition
	result = doSomething(a, b)
	println("Result : $result")

					// Lambda Expression Having Type (Int, Int) -> Int
	doSomething = { x: Int, y: Int -> x - y } // Lambda To Do Substraction
	result = doSomething(a, b)
	println("Result : $result")

					// Lambda Expression Having Type (Int, Int) -> Int
	doSomething = { x: Int, y: Int -> x * y } // Lambda To Do Multiplication
	result = doSomething(a, b)
	println("Result : $result")

					// Lambda Expression Having Type (Int, Int) -> Int
	doSomething = { x: Int, y: Int -> x / y } // Lambda To Do Division
	result = doSomething(a, b)
	println("Result : $result")
}

fun calcualtor(a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
	return operation(a, b)
}

fun playWithLamdbaExpression3() {
	val a = 200
	val b = 100
	var result: Int
	var doSomething: (Int, Int) -> Int

			  		// Lambda Expression Having Type (Int, Int) -> Int
	doSomething = { x: Int, y: Int -> x + y } // Lambda To Do Addition
	result = calcualtor(a, b, doSomething)
	println("Result : $result")

					// Lambda Expression Having Type (Int, Int) -> Int
	doSomething = { x: Int, y: Int -> x - y } // Lambda To Do Substraction
	result = calcualtor(a, b, doSomething)
	println("Result : $result")

					// Lambda Expression Having Type (Int, Int) -> Int
	doSomething = { x: Int, y: Int -> x * y } // Lambda To Do Multiplication
	result = calcualtor(a, b, doSomething)
	println("Result : $result")

					// Lambda Expression Having Type (Int, Int) -> Int
	doSomething = { x: Int, y: Int -> x / y } // Lambda To Do Division
	result = calcualtor(a, b, doSomething)
	println("Result : $result")
}

fun playWithLamdbaExpression4() {
	var result: Int
	
	val addition: (Int, Int) -> Int = { a: Int, b: Int -> a + b }
	result = addition(11, 22)
	println("Result : $result")

	val twiceValue: (Int) -> Int = { a : Int -> 2 * a }
	result = twiceValue(90)
	println("Result : $result")

	// One Argument Lambda
	// 	One Argument Can Be Accessed With Special Name: it
	//	As Well As No Need To Specify Arguments, Rather Directly Write Body
	//	Must Specify Type of The Lambda
	//						Lambda Body
	val twiceValueAgain: (Int) -> Int = { 2 * it }
	result = twiceValueAgain(90)
	println("Result : $result")

	val squareValue: (Int) -> Int = { it * it }
	result = squareValue(25)
	println("Result : $result")
}

//__________________________________________________________________

fun additionFunction(a: Int, b: Int): Int {
	return a + b
}

fun playWithLamdbaExpression5() {
	var result: Int

	// Passing Function Reference As Argument
	result = calcualtor(19, 11, ::additionFunction)
	println("Result : $result")

	//Storing Lamdba in Variable
	val doAddition = { x: Int, y: Int -> x + y } 
	// Passing Lambda Variable To Function
	result = calcualtor(19, 11, doAddition ) 
	println("Result : $result")

	// Passing Lamdba As Argument Directly
	result = calcualtor(19, 11, { x: Int, y: Int -> x + y } )
	println("Result : $result")
}

fun playWithLamdbaExpression6() {
	// Following Lamdba Takes No Arguments and Return Unit Value of Unit Type
	var unitLamdba: () -> Unit = { println("Balleeee Balleeee") };
	unitLamdba()

	// Following Lamdba Takes No Arguments and Return Nothing Value of Nothing Type
	// var nothingLambda: () -> Nothing = { throw NullPointerException() }
	// nothingLambda()
}

//__________________________________________________________________

enum class Operation { ADDITION, SUBSTRACTION, MULTIPLICATION, DIVISION }

fun additionFun(a: Int, b: Int): Int 	 	{ return a + b }
fun substractionFun(a: Int, b: Int): Int 	{ return a - b }
fun mutliplicationFun(a: Int, b: Int): Int 	{ return a * b }
fun divisionFun(a: Int, b: Int): Int 		{ return a / b }

// Function Returning A Function
//  	Function Takes Argument of Operation Type
//		Return Function of Type (Int, Int) -> Int
fun chooseFunction(choice: Operation): (Int, Int) -> Int {
	return when(choice) {
		Operation.ADDITION 		-> ::additionFun
		Operation.SUBSTRACTION  -> ::substractionFun
		Operation.MULTIPLICATION-> ::mutliplicationFun
		Operation.DIVISION 		-> ::divisionFun
		// else 					-> { _: Int, _: Int -> 0 }
	}
}

fun playWithChooseFunction() {
	var result: Int
	var something: (Int, Int) -> Int
	
	something = chooseFunction( Operation.ADDITION )
	result = something(333, 200)
	println("Result : $result")

	something = chooseFunction( Operation.SUBSTRACTION )
	result = something(333, 200)
	println("Result : $result")

	something = chooseFunction( Operation.MULTIPLICATION )
	result = something(333, 200)		
	println("Result : $result")

	something = chooseFunction( Operation.DIVISION )
	result = something(333, 200)
	println("Result : $result")
}

//__________________________________________________________________
// Enclosing Function Returing Nested Function
// 		It Returns Function of Type () -> Int
// Enclosing Function
fun chooseStepFunction(choice: Boolean): () -> Int {
	var counter = 10 // counter variable Part of Enclosing Function
	// Nested Function
	// 	Capture Values From Enclosing Function
	fun stepForward(): Int {
		// Capture Value For counter is 10
		counter = counter + 1
		return counter
	}

	fun stepBackward(): Int {
		// Capture Value For counter is 10
		counter = counter - 1
		return counter
	}

	return if (choice) ::stepForward else ::stepBackward
}

fun playWithChooseStepFunction() {
	var result: Int 

	// Returns stepForward Function
	// incement Stores stepForward Function
	val increment: () -> Int = chooseStepFunction(true) 
	
	result = increment()
	println("Incementing Captured Value of Counter")	
	println("Result : $result")
	result = increment()
	println("Result : $result")
	result = increment()
	println("Result : $result")
	result = increment()
	println("Result : $result")

	val decrement: () -> Int = chooseStepFunction(false)
	println("Decrementing Captured Value of Counter")	
	result = decrement()
	println("Result : $result")
	result = decrement()
	println("Result : $result")
	result = decrement()
	println("Result : $result")
	result = decrement()
	println("Result : $result")
}

//__________________________________________________________________

fun main() {
	println("\nFunction: playWithSum")
	playWithSum()

	println("\nFunction: playWithLamdbaExpression1")
	playWithLamdbaExpression1()

	println("\nFunction: playWithLamdbaExpression2")
	playWithLamdbaExpression2()

	println("\nFunction: playWithLamdbaExpression3")
	playWithLamdbaExpression3()

	println("\nFunction: playWithLamdbaExpression4")
	playWithLamdbaExpression4()
	
	println("\nFunction: playWithLamdbaExpression5")
	playWithLamdbaExpression5()
	
	println("\nFunction: playWithLamdbaExpression6")
	playWithLamdbaExpression6()

	println("\nFunction: playWithChooseFunction")
	playWithChooseFunction()

	println("\nFunction: playWithChooseStepFunction")
	playWithChooseStepFunction()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}