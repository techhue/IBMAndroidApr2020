
Participants Guidelines
_____________________________________________________________
	Participants ​must​ know
	Concepts of Object Oriented Programming
	Programming in C and Java/C++/C# etc. Language
	Energy and Openness to Learn, Attitude to Take Ownership 
	Appreciation and Openness to Design Thinking Understanding and Appreciation of Mathematics 10+2 Level Strong Logical and Programming Ability
	Following Training Schedule and Decorum
	Arriving on Time and Avoiding Distractions
_____________________________________________________________


DAY 01
_____________________________________________________________
	
	READING ASSIGNMENT
	__________________________________________________________
		Data Type Chapter
			Programming In C, Kernigham and Denish Ritchie

	CODING AND PRACTICE ASSIGNMENTS
	__________________________________________________________
		Code and Practice Kotlin Code Shared


DAY 02
_____________________________________________________________

	CODING AND PRACTICE ASSIGNMENTS
	__________________________________________________________
		Code and Practice Kotlin Code Shared


DAY 03
_____________________________________________________________

	READING ASSIGNMENT
	__________________________________________________________
		Kotlin Notes 
			KN2. Expressions, Variables and Constants 
			KN3. Types and Operations 
			KN4. Basic Control Flow 
			KN5. Functions 

	
	CODING AND PRACTICE ASSIGNMENTS
	__________________________________________________________
		CP1. Kotlin Code Shared
			Revise and Practice
		
		CP2. Kotlin Notes Code 
			Type and Practice
		
		CP3. Solve Kotlin Notes Challenges Problems
			Solve It

DAY 04
_____________________________________________________________

	READING ASSIGNMENT
	__________________________________________________________
		Kotlin Notes 
			KN2. Expressions, Variables and Constants 
			KN3. Types and Operations 
			KN4. Basic Control Flow 
			KN5. Functions 
	
	CODING AND PRACTICE ASSIGNMENTS
	__________________________________________________________
		CP1. Kotlin Code Shared Till Today
			Revise and Practice
		
		CP2. Kotlin Notes Code 
			Type and Practice
		
		CP3. Solve Kotlin Notes Challenges Problems and Excercises
			Solve It

DAY 05
_____________________________________________________________

	READING ASSIGNMENT [MUST]
	__________________________________________________________
		Kotlin Notes 
			KN6. Arrays and Lists
			KN7. Maps and Sets

		Arrays And Pointer Chapter
			Programming In C, 2nd Edition
				By Kernigham and Denish Ritchie

	CODING AND PRACTICE ASSIGNMENTS
	__________________________________________________________
		CP1. Kotlin Code Shared Till Today
			Revise and Practice
		
		CP2. Kotlin Notes: Chapter Code 
			Type It and Practice
		
		CP3. Kotlin Notes: Solve Challenges Problems and Excercises
			Solve It

DAY 06
_____________________________________________________________

	READING ASSIGNMENT [MUST]
	__________________________________________________________
		Kotlin Notes 
			KN2. Expressions, Variables and Constants 
			KN3. Types and Operations 
			KN4. Basic Control Flow 
			KN5. Functions 

			KN6. Nullability
			KN7. Arrays and Lists
			KN8. Maps and Sets
			KN9. Lambdas

		Arrays And Pointer Chapter
			Programming In C, 2nd Edition
				By Kernigham and Denish Ritchie

	CODING AND PRACTICE ASSIGNMENTS
	__________________________________________________________
		CP0. Complete Calculator Code Example

		CP1. Kotlin Code Shared Till Today
			Revise and Practice
		
		CP2. Kotlin Notes: Chapter Code 
			Type It and Practice
		
		CP3. Kotlin Notes: Solve Challenges Problems and Excercises
			Solve It

		CP4. Arrays And Pointer Code Examples and Excercises
			Type It and Practice


+++++++++++++++++++++++++++++++++++++++++++++++++++++
>>>				COMPLETE ABOVE THINGS
>>>				   THAN RAISE HAND
+++++++++++++++++++++++++++++++++++++++++++++++++++++



Working With Google Sheet 
_____________________________________________________________
 	NOTE: 
 	First Select Cell In Your Name Row
 	Then Paste In Fx Text Box At Top
 		It Will Paste Full Code In Your Cell Only


