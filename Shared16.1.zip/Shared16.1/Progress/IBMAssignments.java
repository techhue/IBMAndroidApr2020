
Participants Guidelines
_____________________________________________________________
	Participants ​must​ know
	Concepts of Object Oriented Programming
	Programming in C and Java/C++/C# etc. Language
	Energy and Openness to Learn, Attitude to Take Ownership 
	Appreciation and Openness to Design Thinking Understanding and Appreciation of Mathematics 10+2 Level Strong Logical and Programming Ability
	Following Training Schedule and Decorum
	Arriving on Time and Avoiding Distractions
_____________________________________________________________


DAY 01
_____________________________________________________________
	
	READING ASSIGNMENT
	__________________________________________________________
		Data Type Chapter
			Programming In C, Kernigham and Denish Ritchie

	CODING AND PRACTICE ASSIGNMENTS
	__________________________________________________________
		Code and Practice Kotlin Code Shared


DAY 02
_____________________________________________________________

	CODING AND PRACTICE ASSIGNMENTS
	__________________________________________________________
		Code and Practice Kotlin Code Shared


DAY 03
_____________________________________________________________

	READING ASSIGNMENT
	__________________________________________________________
		Kotlin Notes 
			KN2. Expressions, Variables and Constants 
			KN3. Types and Operations 
			KN4. Basic Control Flow 
			KN5. Functions 

	
	CODING AND PRACTICE ASSIGNMENTS
	__________________________________________________________
		CP1. Kotlin Code Shared
			Revise and Practice
		
		CP2. Kotlin Notes Code 
			Type and Practice
		
		CP3. Solve Kotlin Notes Challenges Problems
			Solve It

DAY 04
_____________________________________________________________

	READING ASSIGNMENT
	__________________________________________________________
		Kotlin Notes 
			KN2. Expressions, Variables and Constants 
			KN3. Types and Operations 
			KN4. Basic Control Flow 
			KN5. Functions 
	
	CODING AND PRACTICE ASSIGNMENTS
	__________________________________________________________
		CP1. Kotlin Code Shared Till Today
			Revise and Practice
		
		CP2. Kotlin Notes Code 
			Type and Practice
		
		CP3. Solve Kotlin Notes Challenges Problems and Excercises
			Solve It

DAY 05
_____________________________________________________________

	READING ASSIGNMENT [MUST]
	__________________________________________________________
		Kotlin Notes 
			KN6. Arrays and Lists
			KN7. Maps and Sets

		Arrays And Pointer Chapter
			Programming In C, 2nd Edition
				By Kernigham and Denish Ritchie

	CODING AND PRACTICE ASSIGNMENTS
	__________________________________________________________
		CP1. Kotlin Code Shared Till Today
			Revise and Practice
		
		CP2. Kotlin Notes: Chapter Code 
			Type It and Practice
		
		CP3. Kotlin Notes: Solve Challenges Problems and Excercises
			Solve It

DAY 06
_____________________________________________________________

	READING ASSIGNMENT [MUST]
	__________________________________________________________
		Kotlin Notes 
			KN2. Expressions, Variables and Constants 
			KN3. Types and Operations 
			KN4. Basic Control Flow 
			KN5. Functions 

			KN6. Nullability
			KN7. Arrays and Lists
			KN8. Maps and Sets
			KN9. Lambdas

		Arrays And Pointer Chapter
			Programming In C, 2nd Edition
				By Kernigham and Denish Ritchie

	CODING AND PRACTICE ASSIGNMENTS
	__________________________________________________________
		CP0. Complete Calculator Code Example

		CP1. Kotlin Code Shared Till Today
			Revise and Practice
		
		CP2. Kotlin Notes: Chapter Code 
			Type It and Practice
		
		CP3. Kotlin Notes: Solve Challenges Problems and Excercises
			Solve It

		CP4. Arrays And Pointer Code Examples and Excercises
			Type It and Practice


DAY 07
_____________________________________________________________

	READING ASSIGNMENT [MUST]
	__________________________________________________________
		Kotlin Notes 
			KN6. Nullability
			KN9. Lambdas

		Arrays And Pointer Chapter
			Programming In C, 2nd Edition
				By Kernigham and Denish Ritchie

	CODING AND PRACTICE ASSIGNMENTS
	__________________________________________________________
		CP1. Kotlin Code Shared Till Today
			Revise and Practice
		
		CP2. Kotlin Notes: Chapter Code 
			Type It and Practice
		
		CP3. Kotlin Notes: Solve Challenges Problems and Excercises
			Solve It

		CP4. Arrays And Pointer Code Examples and Excercises
			Type It and Practice

DAY 08
_____________________________________________________________

	READING ASSIGNMENT [MUST]
	__________________________________________________________
		Kotlin Notes 
			KN6. Nullability
			KN9. Lambdas
			KN10. Classes

		Arrays And Pointer Chapter
			Programming In C, 2nd Edition
				By Kernigham and Denish Ritchie

	CODING AND PRACTICE ASSIGNMENTS
	__________________________________________________________
		CP1. Kotlin Code Shared Till Today
			Revise and Practice
		
		CP2. Kotlin Notes: Chapter Code 
			Type It and Practice
		
		CP3. Kotlin Notes: Solve Challenges Problems and Excercises
			Solve It

		CP4. Arrays And Pointer Code Examples and Excercises
			Type It and Practice

DAY 09
_____________________________________________________________

	READING ASSIGNMENT [MUST]
	__________________________________________________________
		Kotlin Notes 
			KN6. Nullability
			KN9. Lambdas
			KN10. Classes
			KN11. Object

	CODING AND PRACTICE ASSIGNMENTS
	__________________________________________________________
		CP1. Kotlin Code Shared Till Today
			Revise and Practice
		
		CP2. Kotlin Notes: Chapter Code 
			Type It and Practice
		
		CP3. Kotlin Notes: Solve Challenges Problems and Excercises
			Solve It

DAY 10
_____________________________________________________________

	READING ASSIGNMENT [MUST]
	__________________________________________________________
		Kotlin Notes 
			KN10. Classes
			KN11. Object
			KN12. Properties

	CODING AND PRACTICE ASSIGNMENTS
	__________________________________________________________
		CP1. Kotlin Code Shared Till Today
			Revise and Practice
		
		CP2. Kotlin Notes: Chapter Code 
			Type It and Practice
		
		CP3. Kotlin Notes: Solve Challenges Problems and Excercises
			Solve It

DAY 11
______________________________________________________________

	READING ASSIGNMENT [MUST]
	__________________________________________________________
		Kotlin Notes [ REVISE THROUGHLY ]
			KN2. Expressions, Variables and Constants 
			KN3. Types and Operations 
			KN4. Basic Control Flow 
			KN5. Functions 
			KN6. Nullability
			KN7. Arrays and Lists
			KN8. Maps and Sets
			KN9. Lambdas

		Kotlin Notes [ MUST READ AND PRACTICES ]
			KN10. Classes
			KN11. Object
			KN12. Properties
			KN13. Methods
			KN14. Advanced Classes
			KN15. Enum Classes
			KN16. Interfaces

	CODING AND PRACTICE ASSIGNMENTS
	__________________________________________________________
		CP1. Kotlin Code Shared Till Today
			Revise and Practice
		
		CP2. Kotlin Notes: Chapter Code 
			Type It and Practice
		
		CP3. Kotlin Notes: Solve Challenges Problems and Excercises
			Solve It

		CP4. Java Programming Hands On
			Chapters 01 to 10
			Chapter : Threading
			Chapter : Java Collections


DAY 12 and 13
______________________________________________________________

	READING ASSIGNMENTS: PRESENTATIONS [MUST]
	__________________________________________________________
		01.0 Introduction to Android.pdf
		01.1 Your first Android app.pdf
		01.2 Layouts and resources for the UI-Part1.pdf

	READING ASSIGNMENT [MUST]
	__________________________________________________________
		https://developer.android.com/guide/platform
		https://developer.android.com/studio/run/managing-avds.html
		https://developer.android.com/training/basics/supporting-devices/platforms.html

	CODING AND PRACTICE ASSIGNMENTS
	__________________________________________________________
		HelloWorld

		Android.Code1 > Project03
			Project.03.01.ManifestAndResources
			Project.03.02.Snippets
			Project.03.03.ConfigChanges
			Project.03.04.Activities

DAY 14
______________________________________________________________

	READING ASSIGNMENTS: PRESENTATIONS [MUST]
	__________________________________________________________
		01.2 Layouts and resources for the UI.pdf

	READING ASSIGNMENT [MUST]
	__________________________________________________________
		https://developer.android.com/guide/platform
		https://developer.android.com/guide/components/activities/activity-lifecycle
		https://developer.android.com/guide/practices/screens_support
		https://developer.android.com/training/multiscreen/screendensities

	CODING AND PRACTICE ASSIGNMENTS
	__________________________________________________________
		HelloWorld

		Android.Code1 > Project03
			Project.03.01.ManifestAndResources
			Project.03.02.Snippets
			
			Project.03.03.ConfigChanges // Revise This Code Example
			Project.03.04.Activities  	// Experiment With This
		
		Android.Code2 > Project04
			Project04.01.Layouts		// <<<<<<<<<< Complete This One
			Project04.03.Views			// <<<<<<<<<< Complete This One
			Project04.04.Adapters		// <<<<<<<<<< Complete This One

DAY 15
______________________________________________________________

	READING ASSIGNMENTS: PRESENTATIONS [ MUST ]
	__________________________________________________________
		01.0 Introduction to Android.pdf
		01.1 Your first Android app.pdf
		01.2 Layouts and resources for the UI.pdf
		01.3 Text and scrolling views.pdf
		01.4 Resources to help you learn.pdf

		02.1 Activities and Intents.pdf
		02.2 Activity lifecycle and state.pdf
		02.3 Implicit Intents.pdf
		
		03.1 The Android Studio debugger.pdf
		03.2 App testing.pdf
		03.3 The Android Support Library.pdf
		
		04.1 Buttons and clickable images.pdf
		04.2 Input controls.pdf
		04.3 Menus and pickers.pdf
		04.4 User navigation.pdf
		04.5 RecyclerView.pdf

	READING AASSIGNMENTS [ MUST ]
	__________________________________________________________
		https://developer.android.com/guide/platform
		https://developer.android.com/studio/run/managing-avds.html
		https://developer.android.com/training/basics/supporting-devices/platforms.html

		https://developer.android.com/guide/practices/screens_support
		https://developer.android.com/training/multiscreen/screendensities
		https://developer.android.com/guide/topics/resources/providing-resources

		https://developer.android.com/guide/components/fundamentals
		https://developer.android.com/guide/components/activities/intro-activities
		https://developer.android.com/guide/components/activities/activity-lifecycle
		https://developer.android.com/guide/components/activities/state-changes
		https://developer.android.com/guide/components/intents-filters

		https://guides.codepath.com/android/Using-an-ArrayAdapter-with-ListView
	
	CODING AND PRACTICE ASSIGNMENTS REVISE [ MUST ]
	__________________________________________________________
		Android.Code2 > Project04
			Project04.01.Layouts		
			Project04.03.Views			
			Project04.04.Adapters		
		
		Android.Code3
			AndroidFundamentalsDemo		
			Project.05.01.Intents		

	PROJECT WORK [ MUST ]
	__________________________________________________________		
		
		1. Practice Layouts Project
			Using Kotlin Language
			Follow Following Tutorial
			https://guides.codepath.com/android/Constructing-View-Layouts

		2. First Android App Project 
			Using Kotlin Language
			Follow Following Tutorial
				https://developer.android.com/training/basics/firstapp
				https://developer.android.com/training/basics/firstapp/creating-project
				https://developer.android.com/training/basics/firstapp/running-app
				https://developer.android.com/training/basics/firstapp/building-ui
				https://developer.android.com/training/basics/firstapp/starting-activity
		
		3. RecyclerView Project
			Using Kotlin Language
			Follow Following Tutorial
			https://guides.codepath.com/android/using-the-recyclerview			


DAY 16
______________________________________________________________

	READING ASSIGNMENTS: PRESENTATIONS [ MUST ]
	__________________________________________________________
		05.1 Drawables, styles, and themes.pdf
		05.2 Material Design.pdf
		05.3 Resources for adaptive layouts.pdf
		06.1 UI testing.pdf
		07.1 AsyncTask and AsyncTaskLoader.pdf
		07.2 Internet connection.pdf
		07.3 Broadcasts.pdf
		07.4 Services.pdf

	READING AASSIGNMENTS [ MUST ]
	__________________________________________________________
		https://developer.android.com/guide/components/fragments


	CODING AND PRACTICE ASSIGNMENTS REVISE [ MUST ]
	__________________________________________________________

		Android.Code.Fragments
			AndroidFragmentBasicDemo
			AndroidFragmentPizzaMenu
		
		Android.Code.Services
			AndroidServicesDemo
			Project.09.01.MyService

	PROJECT WORK [ MUST ]
	__________________________________________________________		
	
		TimeFighter Game Code And Complete
			Reference: Android.Notes1.Shared.pdf

DAY 17
______________________________________________________________

	READING ASSIGNMENTS: PRESENTATIONS [ MUST ]
	__________________________________________________________
		Android.Notes1.Shared.pdf
		Android.Notes2.Shared.pdf
		Android.Notes3.Shared.pdf

		07.1 AsyncTask and AsyncTaskLoader.pdf
		07.2 Internet connection.pdf
		07.3 Broadcasts.pdf
		07.4 Services.pdf
		08.1 Notifications.pdf
		08.2 Alarms.pdf
		08.3 Efficient data transfer and JobScheduler.pdf
		09.0 Data Storage.pdf
		09.1 Shared Preferences.pdf
		09.2 App settings.pdf
		10.0 SQLite Primer.pdf
		10.1 Room, LiveData, and ViewModel.pdf

	READING AASSIGNMENTS [ MUST ]
	__________________________________________________________
		https://developer.android.com/guide/components/services
		https://developer.android.com/guide/components/broadcasts
		https://developer.android.com/reference/android/os/AsyncTask
		https://developer.android.com/guide/components/intents-filters

	CODING AND PRACTICE ASSIGNMENTS [ MUST ]
	__________________________________________________________
		
		Android.Code.Concepts1.Working
			BoundServices		
			IntentService
			BroadcastReceiver

		Android.Code.Concepts1.Working2
			SQLite
			UsingRoomORM
			Notification
			Intents						


	PROJECT WORK [ MUST ]
	__________________________________________________________		
	
		Implement Android Proejct In Kotlin
			Android Developer Fundamentals Version 2
			Study Following Link And Code Project In Kotlin
			
			Reference Link: https://codelabs.developers.google.com/android-training/
			Deadline: Coming Monday, 8th June

		List App Project
			Reference: Android.Notes2.Shared.pdf


+++++++++++++++++++++++++++++++++++++++++++++++++++++
>>>				COMPLETE ABOVE THINGS
>>>				   THAN RAISE HAND
+++++++++++++++++++++++++++++++++++++++++++++++++++++



