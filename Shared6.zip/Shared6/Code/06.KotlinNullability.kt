
package learnKotin

fun playWithNullability( ) {
	// Non Nullable Type
	//		It Stores ONLY Valid Values
	//		It's Default
	//
	var nonNullableString: String = "Hello World!"
	// Following Code Will Give Error
	// someString = null
	println(nonNullableString)

	// Nullable Type
	// 		Will Store Valid Value 
	// 		or Not A Valid Value
	//			Represeted By null
	
	// Nullable String
	//Can store null value in nullableString Variable
	var nullableString: String? = null
	
	println(nullableString)
	nullableString = "Hello World!"
	println(nullableString)
}

fun playWithNullability1() {
	var something: Int? = 30
	println(something)

	// println(something + 1)
	// error: operator call corresponds to a dot-qualified call 'something.plus(1)' which is not allowed on a nullable receiver 'something'.

	// println(something.plus(1))
	 //error: only safe (?.) or non-null asserted (!!.) calls are allowed on a nullable receiver of type Int?
	
	println(something?.plus(1))
	
	// something = null
	// NOT RECOMMENDED TO USE !! Operator
	// println(something!! + 1) // Will Give NullPointerException

	// ?: is Elvis Operator 
	var somethingValue = something ?: 0 // Default Value
	println(somethingValue + 1)

	something = null
	somethingValue = something ?: 0 // Default Value
	println(somethingValue + 1)
	// Above Line of Code is Equivalent To
	somethingValue = if (something != null ) something else 0
	println(somethingValue + 1)

}

fun main() {
	println("\nFunction: playWithNullability")
	playWithNullability()

	println("\nFunction: playWithNullability1")
	playWithNullability1()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

