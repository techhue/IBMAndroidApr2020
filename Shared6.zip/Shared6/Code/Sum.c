
#include<stdio.h>

// Write Sum Function
//  	Which Returns Valid Sum
//		Or Print Cann't Calculate Sum
// 			For Given X and Y Values

// API Changes Are Not Allowed
int sum(int x, int y) {
	int result = 0;
	result = x + y;
	return result;
}

int main() {
	// int a = 90909090909090111;
	// int b = 10000000000000111;

	int a = 2147483647;
	int b = 111;

	int result = sum(a, b);

	printf("Result : %d\n", result);

	// Expected Result: 2147483758
	// Result : -2147483538
}

