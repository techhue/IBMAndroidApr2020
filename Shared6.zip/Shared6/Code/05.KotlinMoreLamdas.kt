
package learnKotlin

class Person(val name: String, val age: Int)

fun findTheOldest(people: List<Person>):  Person? {
	var maxAge = 0
	var theOldest: Person? = null

	for (person in people) {
		if (person.age > maxAge) {
			maxAge = person.age
			theOldest = person
		}
	}
	return theOldest
}

fun playWithFindTheOldest() {
	val people = listOf(Person("Ram Singh", 30), Person("Veeru", 27), Person("Gabbar Singh", 35), Person("Basanti", 25))

	val oldestPerson: Person? = findTheOldest(people)
	
	println("Oldest Person: ${oldestPerson?.name}, ${oldestPerson?.age}" )

	 // error: only safe (?.) or non-null asserted (!!.) calls are allowed on a nullable receiver of type Person?
}

fun main() {
	println("\nFunction: playWithFindTheOldest")
	playWithFindTheOldest()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}