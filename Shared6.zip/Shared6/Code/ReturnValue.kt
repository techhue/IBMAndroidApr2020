
package learnKotin


// Statement : One Complete Logical Language Construct
// Expression: It Is A Statement With Return Value
fun main() {
	val x = 0
	var y: Int
	var z: Int
	// In C/C++/Java : if-else is Statement
	// In Kotlin : if-else is Expression

	// Return Value Of if-else Expression Have Following Rules
	// For Following if-else Syntax
	// if (LogicalExpr) IfBlock else ElseBlock
	// Value Of Whole Expresssion (if (LogicalExpr) IfBlock else ElseBlock)
	// 		Will Be Equal To Last Expression Evaluated in IfBlock/ElseBlock
	//		Depending on LogicalExpr Value

	val something1 = if (x == 10) { y = 100; y = y + 1 } else { y = 200; z = 90 }
	println("something Value: $something1")

	val something2 = if ( x == 10 ) 100 else 200
	println("something Value: $something2")
}

