package learnKotlin

fun incrementValue(value: Int) {
	// By Default Arguments of Function Are IMMUTABLE
	// value = value + 1   // error: val cannot be reassigned
	println(value) 
	
	val newValue = value + 1
	println(newValue)
}

// Function Overloading
//	 	Can Overload Function Based On Number of Arguments
//	 	Can Overload Function Based On Type of Arguments
// NOTE: Return Type Will Be Sufficient To Overload Functions

// In Kotlin: Function Can Be Assigned Values
//		Return Type Of Function
//			Inferenced From Right Hand Side Expression		

fun sum(x: Int, y: Int) = x + y
fun sum(x: Int, y: Int, z: Int) = x + y + z
fun sum(x: Float, y: Float) = x + y
fun sum(x: Float, y: Float, z: Float) = x + y + z


fun addition(a: Int, b: Int) : Int { return a + b }
fun substraction(a: Int, b: Int) : Int { return a - b }
fun multiplication(a: Int, b: Int) : Int { return a * b }
fun divison(a: Int, b: Int) : Int { return b / a }

fun addition3(a: Int, b: Int, c: Int) : Int { return a + b + c }

// Function is Variable
fun playWithFunctions() {
	val a = 101
	val b = 202
	var result: Int
	
	result = addition(a, b)
	println("addition Function Result: $result")

	// ::FUNCTION_NAME gives reference of Function
	// ::addition is Reference of Function addition
	// something is a Variable Which Is Storing Function
	
	// Type of somthing is Function 
	// 		Which Takes 2 Int Arguments and Return Int
	
	var something: (Int, Int) -> Int = ::addition
	
	result = something(a, b)
	println("something Result: $result")

	something = ::substraction
	result = something(a, b)
	println("something Result: $result")

	something = ::multiplication
	result = something(a, b)
	println("something Result: $result")

	//  error: type mismatch: inferred type is 
	//	KFunction3<@ParameterName Int, @ParameterName Int, @ParameterName Int, Int> 
	//	but (Int, Int) -> Int was expected
	
	// Error 
	// Trying To Assign A Function Which Takes (Int, Int, Int) -> Int
	//	To A Variable something Which Takes (Int, Int) -> Int
	// something = ::addition3 
}

// Calculator is a Function Which Takes 3 Arguments
//		First 2 Arguments Are Int Type
//		Last Argument Is Function Type (Int, Int) -> Int
//		Calculator Return Type Is Int

// Passing a Function To Function
fun calculator(a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
	return operation(a, b)
}

fun playWithCalculator() {
	val a = 100
	val b = 20
	var result : Int 	

	result = calculator(a, b, ::addition)
	println("Result Is: $result")

	result = calculator(a, b, ::substraction)
	println("Result Is: $result")

	result = calculator(a, b, ::multiplication)
	println("Result Is: $result")

	// What is Type of something Variable?
	val something: (Int, Int, (Int, Int)-> Int ) -> Int = ::calculator  
	result = something(a, b, ::addition)
	println("Result Is: $result")	
}

fun hello() : String {  return "Hello World!"  }
fun isEven(number: Int) : Boolean {
	return if ( number % 2 == 0 ) true else false
}
fun playWithFunctionAsVariables() {
	var result1 = hello() // What is type of result1 ???
	// var result1: String = hello() // What is type of result1 ???
	println("Result Is: $result1")	

	// val something1 = ::hello // What is type of something1 ???
	// val something1: String = ::hello // Error Type Mismatch
	// error: type mismatch: 
	// 	 inferred type is KFunction0<String> but String was expected
	val something1: () -> String = ::hello //
	// something1 is variable of type function 
	//		which takes no arguments and Return Type String
	
	result1 = something1()
	println("Result Is: $result1")	
	// val something2: Boolean = ::isEven  // What is type of something? ???
	//error: type mismatch: 
	// inferred type is KFunction1<@ParameterName Int, Boolean> but Boolean was expected
	val something2: (Int) -> Boolean = ::isEven  
	// What is type of something2 ???
	
	val result2 = something2(100)
	println("Result Is: $result2")	
}


fun doSomething(a: Int, b: Float): Float {
	return a * b
}

fun doSomething1(a: Int, b: Int, c: Int): Int {
	return a + b + c 
}

fun doSomething2(a: String, b: String, flag: Boolean): String {
	return if (flag) a + b else ""
}

fun playWithFunctionAsVariables1() {
	// What is type of something variable?
	// something Type is (Int, Float) -> Float
	
	val something: (Int, Float) -> Float = ::doSomething
	var result = something(10, 90.90F)
	println("Result Is: $result")		

	val something1: (Int, Int, Int) -> Int = ::doSomething1
	val result1 = something1(10, 90, 100)
	println("Result Is: $result1")		

	val something2: (String, String, Boolean) -> String = ::doSomething2
	val result2 = something2("Hello", "World", true)
	println("Result Is: $result2")		
}

//______________________________________________________

fun lastCharacter(string: String): Char {
	return string.get(string.length - 1)
}

// Extenstion Function
// 	lastChar() is Extenstion Funtion On String Type
//	It can be used with any String Object
fun String.lastChar(): Char {
	return this.get(this.length - 1)
}

fun playWithLastCharacter() {
	//Using Function
	var character = lastCharacter("Ding DONG!")
	println("Last Character: $character")

	character = lastCharacter("Hello World")
	println("Last Character: $character")

	//Using Extension Function
	character = "Life Is AWESOME".lastChar()
	println("Last Character: $character")

	character = "Kamal Hasan".lastChar()
	println("Last Character: $character")
}

//______________________________________________________

class Person(var firstName: String, var lastName: String) {
	// Computed Property
	var name: String = ""
		get() {
			return firstName + " " + lastName
		}

	// Member Function
	fun doActing() {
		println("Doing Acting...")
	}
}

// Extension Function
// 	doDance(String) is Extension Function On Person
//	It can be used with any Person Object
fun Person.doDance(danceForm: String) {
	println("Doing Dance ${this.name}: $danceForm")
}

fun playWithPerson() {
	val amitabh = Person("Amitabh", "Bachan")
	println("\nName: ${ amitabh.name }")
	println("First Name: ${amitabh.firstName}")
	println("Last  Name: ${amitabh.lastName}")
	amitabh.doActing()
	amitabh.doDance("Hip Hop")

	val pavan = Person("Pavan", "Vijay")
	println("\nName: ${ pavan.name }")
	println("First Name: ${pavan.firstName}")
	println("Last  Name: ${pavan.lastName}")
	pavan.doActing()
	pavan.doDance("Bhangra!!!")
}

// fun <Int> joinToString(
// 		collection: Collection<Int>,
// 		seperator: String, 
// 		prefix: String,
// 		postfix: String) : String 
// {

// }

// fun <Double> joinToString(
// 		collection: Collection<Double>,
// 		seperator: String, 
// 		prefix: String,
// 		postfix: String) : String 
// {

// }

// fun <String> joinToString(
// 		collection: Collection<String>,
// 		seperator: String, 
// 		prefix: String,
// 		postfix: String) : String 
// {

// }

// Generic Code: Here T is Placeholder Type
// We declare Placeholder just after fun keyward
//	 fun <PLACEHODER> i.e. T is PlaceHolder

fun <T> joinToString(
		collection: Collection<T>, // Collection<T>
		seperator: String, 
		prefix: String,
		postfix: String) : String 
{
	val result = StringBuilder(prefix)

	//collection.withIndex() will generates List of Items with Index
	for ( (index, element) in collection.withIndex() ) {
		if(index > 0) result.append(seperator)
		result.append(element)
	}
	
	result.append(postfix)
	return result.toString()
}

fun playWithJoinToString() {
	val numberList1 = listOf(100, 200, 300)  //ArrayList<Int>
	println(numberList1.javaClass)
	println( joinToString(numberList1, " ; ", "[", "]") )
	println( joinToString(numberList1, " -- ", "#", "#") )

	val numberList2 = listOf(100.90, 200.80, 300.98) //ArrayList<Double>
	println(numberList2.javaClass)
	println( joinToString(numberList2, " ; ", "(", ")") )
	println( joinToString(numberList2, " -- ", "#", "#") )

	//ArrayList<String>
	val namesList1 = listOf("Ram Singh", "Rajnikant Gaekwad", "Surya Vijay")
	println(namesList1.javaClass)
	println( joinToString(namesList1, "  ", "[", "]") )
	println( joinToString(namesList1, " == ", "##", "##") )
	
	var something = joinToString(namesList1, ", ", "", "")
	println(something)
}

// Extension Function
//		joinToString1(String, String, String): String
//		is Extension Function On Collection<T>
fun <T> Collection<T>.joinToString1(
		// collection: Collection<T>, // Collection<T>
		seperator: String, 
		prefix: String,
		postfix: String) : String 
{
	val result = StringBuilder(prefix)
	
	//collection.withIndex() will generates List of Items with Index
	for ( (index, element) in this.withIndex() ) {
		if(index > 0) result.append(seperator)
		result.append(element)
	}
	
	result.append(postfix)
	return result.toString()
}

fun playWithJoinToString1() {
	val numberList1 = listOf(100, 200, 300)  //ArrayList<Int>
	println(numberList1.javaClass)
	println( numberList1.joinToString1(" ; ", "[", "]") )
	println( numberList1.joinToString1(" -- ", "#", "#") )

	val numberList2 = listOf(100.90, 200.80, 300.98) //ArrayList<Double>
	println(numberList2.javaClass)
	println( numberList2.joinToString1(" ; ", "(", ")") )
	println( numberList2.joinToString1(" -- ", "#", "#") )

	//ArrayList<String>
	val namesList1 = listOf("Ram Singh", "Rajnikant Gaekwad", "Surya Vijay")
	println(namesList1.javaClass)
	println( namesList1.joinToString1("  ", "[", "]") )
	println( namesList1.joinToString1(" == ", "##", "##") )
	
	var something = namesList1.joinToString1(", ", "", "")
	println(something)
}


fun main() {
	println("\nFunction: incrementValue")
	incrementValue(1000)

	println("\nFunction: sum with 2 Int Arguments")
	println(sum(100, 200))

	println("\nFunction: sum with 3 Int Arguments")
	println(sum(100, 200, 300))

	println("\nFunction: sum with 2 Float Arguments")
	println(sum(10.9F, 20.9F))
	
	println("\nFunction: sum with 3 Float Arguments")
	println(sum(10.9F, 20.9F, 300.0F))

	println("\nFunction: playWithFunctions")
	playWithFunctions()

	println("\nFunction: playWithCalculator")
	playWithCalculator()

	println("\nFunction: playWithFunctionAsVariables ")
	playWithFunctionAsVariables()

	println("\nFunction: playWithFunctionAsVariables1")
	playWithFunctionAsVariables1()

	println("\nFunction: playWithLastCharacter")
	playWithLastCharacter()

	println("\nFunction: playWithPerson ")
	playWithPerson()

	println("\nFunction: playWithJoinToString")
	playWithJoinToString()

	println("\nFunction: playWithJoinToString1")
	playWithJoinToString1()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}
