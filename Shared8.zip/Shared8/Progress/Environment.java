Android Application Programming
_______________________________________________________
	Android Programming Can Be Done In Java/Kotlin/C/C++

	Kotlin Programming Language
	Android Application Programming
		Using Kotlin/Java
	Project Work

Environment Preparation
_______________________________________________________
	Already Installed Java?
		Open Command Prompt
		Type Following Command
			javac
			javac -version

	Installation Java JDK
	_______________________________________________________
		First Check Your Machine 64Bit or 32Bit
			Computer Properties Will Show It

		Download Java JDK 8 Link
			https://www.oracle.com/java/technologies/javase-jdk8-downloads.html
			
		For Windows 64 Bit means Windows x64	
			Download File: jdk-8u251-windows-x64.exe
			Size : 211.54 MB
		
		For Windows 32 Bit means Windows x86	
			Download File: jdk-8u251-windows-i586.exe	
			Size : 201.17 MB	

		Now Install Java SDK 8
		Check Java Installation
			javac -version

	Download Kotlin Compiler And Configure
	_______________________________________________________
		1. Download Kotlin Link
			https://github.com/JetBrains/kotlin/releases/tag/v1.3.72

		2. Download Following File:
			kotlin-compiler-1.3.72.zip
		3. Unzip Following File
			kotlin-compiler-1.3.72.zip

			It will unzip in kotlinc Directory

			Add In Environment PATH Variable
				YOUR_UNZIPPED_LOCATION_PATH/kotinc/bin 
		4. Check Kotlin Version On Command Prompt
			kotlinc -version

	Compilation And Running Kotlin Code
	_______________________________________________________
		1.1 Make IBMAndroid Folder inside Documents Folder
		1.2 Create Hello.kt File With Following Code Using VS Code
			
			package learnKotlin 
			
			fun main() {
				println("Hello World!")
			}

		1.3 Save File As Hello.kt In IBMAndroid Folder
		1.4 Open Command Prompt And Change To Folder IBMAndroid
				cd Documents/IBMAndroid

			Command To Check Content Of Folder
				dir 

		2. How To Compile Hello.kt With Kotlin Compiler?
			kotlinc Hello.kt -include-runtime -d hello.jar
	
		3. How To Run Compiled Jar File?
			java -jar hello.jar

	Compilation And Running Kotlin Code
	_______________________________________________________
		1.1 Make IBMAndroid Folder inside Documents Folder
		1.2 Create Hello.java File With Following Code Using VS Code
			
			package learnJava;
			
			public class Hello {
			    public static void main(String[] args) {
			        System.out.println("Hello World!!!");
			    }
			}

		1.3 Save File As Hello.java In IBMAndroid Folder
		1.4 Open Command Prompt And Change To Folder IBMAndroid
				cd Documents/IBMAndroid

			Command To Check Content Of Folder
				dir 

		2.1 Create Folder ClassFiles
		 How To Compile Hello.kt With Kotlin Compiler?
			javac Hello.java -d ClassFiles
			java -cp ClassFiles learnJava.Hello
	
		3. How To Run Compiled Jar File?
			java -jar hello.jar


	Download Android Studio
	_______________________________________________________
		1. Download Andorid Studio Link
			https://developer.android.com/studio
		2.1 Download Android Studio [Windows 64 Bit]
			 Download File: 
				android-studio-ide-192.6392135-windows.zip
				770 MB
		2.2 Unzip Following File
				android-studio-ide-192.6392135-windows.zip


Use Online Kotlin Compiler 
_______________________________________________________
	https://play.kotlinlang.org/

Install Code Editor
_______________________________________________________
	Sublime Text 3
		Link : https://www.sublimetext.com/3

	OR 

	Visual Studio Code
		https://code.visualstudio.com/

	We Will Write Code Using Editor
		To Save Code
			Create IBMAndroidTraining Directory
				in Documents Directory

	They Copy Code In Play Window Online
		https://play.kotlinlang.org/		
		Run Code

+++++++++++++++++++++++++++++++++++++++++++++++++++++++
			AFTER COMPLETING ABOVE STEPS
			Type DONE in Chat Window 
+++++++++++++++++++++++++++++++++++++++++++++++++++++++

