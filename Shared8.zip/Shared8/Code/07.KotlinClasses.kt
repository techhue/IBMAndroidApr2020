
package learnKotlin


//________________________________________________________

interface Clickable {
    fun click()
}

class Button : Clickable {
    override fun click() = println("I was clicked")
}

fun playWithButton() {
    val button = Button()
    button.click()
}

//________________________________________________________

interface Clickable1 {
    // Function Declaration : Abstract Method
    fun click()

    // Fuction Declaration and Definition : Concrete Method
    fun showOff() = println("I'm clickable!")
}

interface Focusable1 {
	// Fuction Declaration and Definition : Concrete Method
    fun setFocus(b: Boolean) = println("I ${if (b) "got" else "lost"} setFocus.")

	// Fuction Declaration and Definition : Concrete Method
    fun showOff() = println("I'm focusable!")
}

// Button1 Implementing Cliclable1 and Focusable1 Interfaces
// 		Implementing Means Can Provide 
//			Implementation Of Functions Declared/Defined In Clickable1/Focusable1
class Button1 : Clickable1, Focusable1 {
    override fun click() = println("I was clicked")

    // override fun showOff() = println("I'm Showing Off!!!")
    
    // Can Reuse Parent Type Implementation Also
    override fun showOff() {
    	super<Focusable1>.showOff()
    	super<Clickable1>.showOff()
    } 
}

fun playWithButton1() {
    val button = Button1()
    button.showOff()
    button.setFocus(true)
    button.click()
}

//________________________________________________________

// Intefaces Are Open By Default
// Interfaces Member Functions Are Also Open By Default
interface Clickable2 {
	// Abstract Method : Function is Declared But Not Defined
	fun click()

	// Concete Method : Function is Declared And Defined
	fun showOff() = println("I,m Clickable2!")
}

// Implementing Interface Clickable2
// In Kotlin : Classes Are Final By Default
//			   It CANN'T Be Subclassed
//		And It's Member Functions Are Also Final By Default
//			   It CANN'T Be Overriden

// In Java	 : Classes Are Open By Default
//			   It CAN Be Subclassed
//		And It's Member Functions Are Also Open By Default
//			   It CAN Be Overriden

open class Button2 : Clickable2 {
	// Abstract Method : Must Define It
	override fun click()   { println("Button2 : Click...")   }

	// Concete Method :  Can Be Redefined
	//		While Redefining Can Reuse Previous Implemenation
	override fun showOff()   { println("Button2 : Showoff...")   }

	// Member Methods Are Final By Default
	// Use open keyword to Open for Subclassing
	//		Note: Once Method is Open It's Open For Every Subclasses
	open fun disable() { println("Button2 : Disable...") }
	open fun animate() { println("Button2 : Animate...") }
}

// Inheritance By Extending Button2
//		Creating SubClass/SubType of Button2
open class FancyButton2 : Button2() {
	
	// click and disable Member Methods Are Open
	// Use final keyword to Disable for Subclassing
	//		Because: Once Method is Open It's Open For Every Subclasses
	final override fun click()   { println("FancyButton2 : Click...")   }
	
	override fun disable() { println("FancyButton2 : Disable...") }
	override fun animate() { println("FancyButton2 : Animate...") }
}

class SuperFancyButton2 : FancyButton2() {
	// override fun click()   { println("FancyButton2 : Click...")   } // Error
	override fun disable() { println("SuperFancyButton2 : Disable...") }

	override fun animate() { println("SuperFancyButton2 : Animate...") }
}

// 84:22: error: this type is final, so it cannot be inherited from
// class FancyButton2 : Button2 {
//                     ^
// 84:22: error: this type has a constructor, and thus must be initialized here

fun playWithButton2() {
    val button = Button2()
    button.click()
    button.showOff()

    val fancyButton = FancyButton2()
    fancyButton.click()
    fancyButton.click()
    fancyButton.showOff()

    val superFancyButton = SuperFancyButton2()
    superFancyButton.click()
    superFancyButton.click()
    superFancyButton.showOff()
}

//________________________________________________________

// Stored Properties
	// firstName and lastName
// Primary Constructor with 2 Arguments
//		Called Memberwise Intialiser
//			Because It Initialises All Stored Properties

data class Person1(var firstName: String, var lastName: String) {
	// Computed Property
	val fullName: String
		get() = "$firstName $lastName"
}

fun playWithPerson1() {
	// Primary Constructor
	// Calling Constructor To Create Object of Person Type
	val person1 = Person1(firstName = "Gabbar", lastName = "Singh")
	println( person1.fullName ) 
	
	val person2 = Person1(firstName = "Ram", lastName = "Singh")
	println( person2.fullName ) 

	val person3 = Person1(firstName = "Shyam", lastName = "Singh")
	println( person3.fullName ) 
}

fun playMoreWithPerson1() {
	//  Reference Assignment
	//	L.H.S means gabbar is reference to Object of Person1 Type
	//	Objects Are Stored At Heap
	//	Generally References Are Stored At Stack
	val gabbar = Person1(firstName = "Gabbar", lastName = "Singh")
	
	//  Reference Assignment
	val something = gabbar
	
	something.firstName = "Something"

	println( gabbar.fullName ) 
	println( something.fullName ) 
}

//________________________________________________________

fun playMoreWithPerson1Again() {
	val gabbar = Person1(firstName = "Gabbar", lastName = "Singh")
	val person1 = Person1(firstName = "Gabbar", lastName = "Singh")
	val person2 = Person1(firstName = "Ram", lastName = "Singh")	
	//  Reference Assignment
	val something = gabbar	

	// === Checks References Equality
	if (gabbar === something) { 
		println("Both Are References To Same Object")
	} else {
		println("Both Are References To Different Object")
	}
	
	if (gabbar === person1) {
		println("Both Are References To Same Object")
	} else {
		println("Both Are References To Different Object")
	}

	// == Checks Object Equality
	if (gabbar == person1) { 
		println("Both Objects Have Same Data")
	} else {
		println("Both Objects Have Different Data")
	}
	
	if (gabbar == person2) {
		println("Both Objects Have Same Data")
	} else {
		println("Both Objects Have Different Data")
	}
}

//________________________________________________________


class Person2(var firstName: String, var lastName: String) {
	// Computed Property
	val fullName: String
		get() = "$firstName $lastName"

	// equals() Function Comes From Parent Type
	//		In Java   : Every Class is Subclass of Object Type
	//		In Kotlin : Every Class is Subclass of Any Type
	// Defautl equal() Function Checks References Only By Default
	// Override equals() Function To Do Complete Object Comparisson
	// 		Operator == will get translated to equals() Function Call

	override fun equals(other: Any?): Boolean { 
		val person: Person2? = other as Person2?
		println("equals() FUNCTION CALLED....")
		return (person?.firstName == firstName && person?.lastName == lastName)
	}

	// toString() Function Comes From Parent Type
	//		In Java   : Every Class is Subclass of Object Type
	//		In Kotlin : Every Class is Subclass of Any Type
	// Default toString() Function Prints Type Of Object with Address
	// Override toString() Function To Print Complete Object
	//		i.e. Data Stored In Properties

	override fun toString(): String {
		println("ToString() FUNCTION CALLED....")
		return "Person2(firstName=$firstName, lastName=$lastName)"
	}
}

fun playMoreWithPerson2() {
	val gabbar = Person2(firstName = "Gabbar", lastName = "Singh")
	val samba = Person2(firstName = "Shamba", lastName = "Singh")
	val ram = Person2(firstName = "Ram", lastName = "Singh")	

	println(gabbar)
	// Compiler Translate prinln(gabbar) To Following Code
			// println(gabbar.toString())
	println(samba)
	// Compiler Translate prinln(samba) To Following Code
		// println(samba.toString())
	println(ram)

	val gabbarAgain = Person2(firstName = "Gabbar", lastName = "Singh")
	val sambaAgain = Person2(firstName = "Shamba", lastName = "Singh")
	val ramAgain = Person2(firstName = "Ram", lastName = "Singh")	
	println(gabbarAgain)
	println(sambaAgain)
	println(ramAgain)

	// == Checks Object Equality Provided It's Overriden
	//		Othewise It Will Compare Only References
	if (gabbar == gabbarAgain) { 
		println("Both Objects Have Same Data")
	} else {
		println("Both Objects Have Different Data")
	}
	
	if (samba == sambaAgain) {
		println("Both Objects Have Same Data")
	} else {
		println("Both Objects Have Different Data")
	}

	if (samba == ram) {
		println("Both Objects Have Same Data")
	} else {
		println("Both Objects Have Different Data")
	}

// Following Output For Default equals() method From Any/Object Type
// Default equals() Function Comapres References Only
	// Both Objects Have Different Data
	// Both Objects Have Different Data
	// Both Objects Have Different Data

// Following Output For Overriden equals() method
	// Both Objects Have Same Data
	// Both Objects Have Same Data
	// Both Objects Have Different Data
}

//________________________________________________________

// Data Classes : Will Generate Following Three Functions
// 		equals() Function Generated
//		hasCode() Function
// 		toString() Function

data class Person3(var firstName: String, var lastName: String) {
	// Computed Property
	val fullName: String
		get() = "$firstName $lastName"

	// Compiler Will Generate Following Functions
	// 		equals() Function Generated
	//				To Compare All Stored Properties of Class
	//		hasCode() Function
	//				Will Caculate HashCode Based On
	//				All Stored Properties of Class
	// 		toString() Function
	//				Will Print All Stored Properties's Values
}

fun playMoreWithPerson3() {
	val gabbar = Person3(firstName = "Gabbar", lastName = "Singh")
	val samba = Person3(firstName = "Shamba", lastName = "Singh")
	val ram = Person3(firstName = "Ram", lastName = "Singh")	

	println(gabbar)
	// Compiler Translate prinln(gabbar) To Following Code
			// println(gabbar.toString())
	println(samba)
	// Compiler Translate prinln(samba) To Following Code
		// println(samba.toString())
	println(ram)

	val gabbarAgain = Person3(firstName = "Gabbar", lastName = "Singh")
	val sambaAgain = Person3(firstName = "Shamba", lastName = "Singh")
	val ramAgain = Person3(firstName = "Ram", lastName = "Singh")	
	println(gabbarAgain)
	println(sambaAgain)
	println(ramAgain)

	if (gabbar == gabbarAgain) { 
		println("Both Objects Have Same Data")
	} else {
		println("Both Objects Have Different Data")
	}
	
	if (samba == sambaAgain) {
		println("Both Objects Have Same Data")
	} else {
		println("Both Objects Have Different Data")
	}

	if (samba == ram) {
		println("Both Objects Have Same Data")
	} else {
		println("Both Objects Have Different Data")
	}
}

//________________________________________________________

data class Person4(
	val firstName: String,
	val lastName: String) 
	// val firstName: String,
	// val lastName: String) 
{
	val fullName: String
		get() = "$firstName $lastName"
}

fun playWithMutabilityImmutability1() {
	// Immutable
	var gabbar = Person4(firstName = "Gabbar", lastName = "Singh")
	
	// Mutable
	var samba  = Person4(firstName = "Shamba", lastName = "Singh")
	println(gabbar)
	println(samba)

	gabbar = Person4(firstName = "Ding", lastName = "Dong") // Error
	
	// gabbar.firstName = "Something"
	// gabbar.lastName  = "Singhania"
	
	println(gabbar)

	samba  = Person4(firstName = "Ting", lastName = "Tong")
	println(samba)
}

//________________________________________________________

data class Grade(val letter: String, val points: Double, val credits: Double)

data class Student(
    val firstName: String,
    val lastName: String,
    // grade is Mutable or Immutable?
    val grades: MutableList<Grade> = mutableListOf(),
    var cumulativeCredits: Double = 0.0) 
{
	fun recordGrade(grade: Grade) {
	    grades.add(grade)
	    cumulativeCredits += grade.credits
	}
}

fun playWithMutabilityImmutability2() {
	// jane is Mutable or Immutable?
	val jane = Student(firstName = "Jane", lastName = "Appleseed")
	println(jane.grades)

	val history = Grade(letter = "B", points = 9.0, credits = 3.0)
	val math = Grade(letter = "A", points = 16.0, credits = 4.0)
	
	jane.recordGrade(history)
	jane.recordGrade(math)
	
	println(jane.grades)
	println(jane)
}

fun playWithMutabilityImmutability3() {
	// jane is Mutable or Immutable?
	val jane = Student(firstName = "Jane", lastName = "Appleseed")
	val history = Grade(letter = "B", points = 9.0, credits = 3.0)
	val math = Grade(letter = "A", points = 16.0, credits = 4.0)
	
	jane.recordGrade(history)
	jane.recordGrade(math)
	println(jane)

	println()
	
	val something = jane
	val science = Grade(letter = "A", points = 10.0, credits = 3.5)
	something.recordGrade(science)
	println(something)
	println(jane)
}

//________________________________________________________

data class Car(val name: String, val brand: String, val model: String, val chassiNumber: Int)

// Singleton Class
// 		A Class Having Only One Instance Possible
// object Class is Singleton Class
//		Instance of This Class Will Be Name Of The Class

object CarFactory {
	val company: String = "Maruti-Suzuki"
	val location: String = "Noida"
	val carsCreated = mutableListOf<Car>()

	fun createCar(name: String, model: String, chassiNumber: Int): Car {
		val car = Car(name, company, model, chassiNumber)
		carsCreated.add(car)
		return car
	}
}

fun playWithCarFactory() {
	// val factory = CarFactory("Maruti-Suzuki", "Noida")
	// val factory1 = CarFactory("Maruti-Suzuki", "Noida")

	var car = CarFactory.createCar("Swift", "Desire", 90909)
	println(car)
	
	car = CarFactory.createCar("Swift", "Desire", 90910)
	println(car)
	
	car = CarFactory.createCar("Swift", "Desire", 90911)
	println(car)
	
	car = CarFactory.createCar("Swift", "Desire", 90912)
	println(car)
	
	car = CarFactory.createCar("Alto", "HatchBack", 70909)
	println(car)
	
	car = CarFactory.createCar("Alto", "HatchBack", 70910)
	println(car)
	
	car = CarFactory.createCar("Celario", "Sedan", 80909)
	println(car)

	car = CarFactory.createCar("Celario", "Sedan", 80910)
	println(car)
}


//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________

fun main() {
	println("\nFunction: playWithButton")
	playWithButton()

	println("\nFunction: playWithButton1")
	playWithButton1()

	println("\nFunction: playWithButton2")
	playWithButton2()

	println("\nFunction: playWithPerson1")
	playWithPerson1()

	println("\nFunction: playMoreWithPerson1")
	playMoreWithPerson1()

	println("\nFunction: playMoreWithPerson1Again")
	playMoreWithPerson1Again()

	println("\nFunction: playMoreWithPerson2")
	playMoreWithPerson2()	
	
	println("\nFunction: playMoreWithPerson3")
	playMoreWithPerson3()

	println("\nFunction: playWithMutabilityImmutability1")
	playWithMutabilityImmutability1()

	println("\nFunction: playWithMutabilityImmutability2")
	playWithMutabilityImmutability2()

	println("\nFunction: playWithMutabilityImmutability3")
	playWithMutabilityImmutability3()
	
	println("\nFunction: playWithCarFactory")
	playWithCarFactory()
	// println("\nFunction: ")
	// println("\nFunction: ")
}

