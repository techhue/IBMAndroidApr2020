
package learnKotlin

// Person Class With Two Properties [Name and isMarried]
	// val means Immutable: name is Constant
	// var means Variable: isMarried can be changed

// In Kotlin: Person Class
// 		It will Generate Constructor with 2 Arugments
//		It will Generate Instance Members for name and isMarried
//		It will Generate Getter and Setters for name and isMarried

class Person(val name: String, var isMarried: Boolean)

fun playWithPerson() {
	// Created person Object of Type Person
	val person = Person("Rajnikant", true)
	person.isMarried = false
	println(person.name)
	println(person.isMarried)
}

// rollno, name and age are Member Properties
// 		means Properties Consist of Member Variable and Getter/Setter

class Student(val rollno: Int, val name: String, var age: Int)

// Above Line of Code Generates Following Things
// 1. Student Class Constructor with 3 Arugments
//		Student(Int, String, Int)
// 2. Instance Members rollno, name and age
// 3. For IMMUTABLE PROPERTIES rollno, name only getter generated
		// i.e. 2 getters
// 4. For MUTABLE PROPERTY age both getter and setter generated
		// i.e. 1 getter and 1 setter

fun playWithStudent() {
	val supriya = Student(1, "Supriya", 22)
	println("${supriya.rollno}")
	println("${supriya.name}")
	println("${supriya.age}")
}


fun main() {
	println("\nFunction: playWithPerson")
	playWithPerson()

	println("\nFunction: playWithStudent")
	playWithStudent()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}
