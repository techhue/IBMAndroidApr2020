
package learnKotlin;

import java.util.Random;
/*
	Kotlin Language
	____________________________________________________
	1. It's Case Sensitive Language
	2. It's Consise and Beautiful Langauage
*/

// Function With No Arguments
fun helloWorld() {
	println("Hello World!")
}

// Function With 2 Int Arguments
	// Return Type Is Int
fun max(a: Int, b: Int): Int {
	return if (a > b) a else b
}

// Person Class With Two Properties [Name and isMarried]
class Person(
	// val means Immutable: name is Constant
	val name: String,
	// var means Variable: isMarried can be changed
	var isMarried: Boolean
)

fun playWithPersonProperties() {
	// Created person Object of Type Person
	val person = Person("Rajnikant", true)
	// Accessing Person Properties

	// person.name = "Kamal Hassan" // Error: Unmodifiable
	person.isMarried = false

	println(person.name)
	println(person.isMarried)
}

// Mutability and Immutability in Kotlin
fun playWithMutability() {
	val notChangableValue = 100 // Immutable : Unmodifiable
	var changableValue = 1000	// Mutable   : Modifiable

//    notChangableValue = 9000 // Error: Val cannot be reassigned
	changableValue = 9090
	println(notChangableValue)
	println(changableValue)
}

// Rectangle Class Have Three Properties
// 		1. Two Stored Properties
//			It Will Stored and Read From There
//			Int Properties height and width
// 		2. One Computed Property
//			It Will Be Calcualted Rather Than Stored
//			Boolean Property isSquare is Computed Property

class Rectangle(
	val height: Int,	// Stored Property
	val width: Int		// Stored Property
){
	val isSquare: Boolean // Computed Property
		// Getter Will Called On Access Of This Property
		get() { 
			return height == width
		}
}

fun playWithRectangle() {
	// rectangle1 is Object of Rectangle Type
	// 		Will Allocate Storage/Memory
	//			Two Properties height and width
	//		But Will Not Allocate Memory for isSquare
	//			This Will Calculated When You Access It
	//				At Runtime

	val rectangle1 = Rectangle(20, 40)
	println(rectangle1.width)
	println(rectangle1.height)

	// Getting Calculated Whenever You Access isSquare
	println(rectangle1.isSquare)

	// Above Line Will Get Translated To Below Line
	// By Compiler
	// println( rectangle1.get_isSquare() )

	val rectangle2 = Rectangle(100, 100)
	println(rectangle2.width)
	println(rectangle2.height)
	println(rectangle2.isSquare)
}

// import java.util.Random;

// Function Returning Rectangle Type Object
fun createRandomRectangle() : Rectangle {
	val random = Random()
	val rectangle = Rectangle(random.nextInt(), random.nextInt())
	return rectangle
}

fun playWithRandomRectangle() {
	println("\nFunction: createRandomeRectangle")
	val rect1 = createRandomRectangle()
	// String Formating
	println("Width: ${rect1.width} Height: ${rect1.height}")

	println("\nFunction: createRandomeRectangle")
	val rect2 = createRandomRectangle()
	println("Width: ${rect2.width} Height: ${rect2.height}")
}

fun main() {
	println("\nFunction: helloWorld")
	helloWorld()

	println("\nFunction: max")
	println(max(-10, 90))

	println("\nFunction: playWithPersonProperties")
	playWithPersonProperties()

	println("\nFunction: playWithMutability")
	playWithMutability()

	println("\nFunction: playWithRectangle")
	playWithRectangle()
}

// 0. Write Above Code In Your Favorite Editor
// 1. Saved In File: Hello.kt
		// Kotlin File Extension Is: .kt
// 2. Copy Code In Online Compiler Window
// 3. Run Code

// +++++++++++++++++++++++++++++++++++++++++++++++++++++++
// 			AFTER COMPLETING ABOVE STEPS
// 			Type DONE in Chat Window 
// +++++++++++++++++++++++++++++++++++++++++++++++++++++++
