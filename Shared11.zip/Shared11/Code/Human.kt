package learnKotlin

interface Superpower {
	fun fly() 
	fun saveWorld()
}

class Spiderman: Superpower {
	override fun fly() 		 {   println("\tFly Like Spiderman!")  	     }
	override fun saveWorld() {   println("\tSaveWorld Like Spiderman!")  }
}

class Superman: Superpower {
	override fun fly() 		 {   println("\tFly Like Superman!")  	     }
	override fun saveWorld() {   println("\tSaveWorld Like Superman!")  }
}

class Batman: Superpower {
	override fun fly() 		 {   println("\tFly Like Batman!")  	     }
	override fun saveWorld() {   println("\tSaveWorld Like Batman!")  }
}

class Ironman: Superpower {
	override fun fly() 		 {   println("\tFly Like Ironman!")  	     }
	override fun saveWorld() {   println("\tSaveWorld Like Ironman!")  }
}

class Wonderwoman: Superpower {
	override fun fly() 		 {   println("\tFly Like Wonderwoman!")  	     }
	override fun saveWorld() {   println("\tSaveWorld Like Wonderwoman!")  }
}

// Human Want To Become Spiderman
// class Human : Spiderman() {
// class Human : Superman() {
// class Human : Batman() {
// 	override fun fly() 		{   super.fly()   }
// 	override fun saveWorld() {   super.saveWorld()   }
// }
// class HumanOld : Spiderman() { // Using Inheritance
// 	override fun fly() 		{   super.fly()   }
// 	override fun saveWorld() {   super.saveWorld()   }
// }

// Using Composition/Delegation
// 		Human is Delegator
// 		power Is Delegate To Whom Work Is Delegated

//_________________________________________________________________________________

class Human {
	// power is called Delegate
	var power: Superpower? = null
	// Delegating Capability To Fly and SaveWorld To Delegate i.e. power
	fun fly() 		{   power?.fly()   }
	fun saveWorld() {   power?.saveWorld()   }	
} 

fun playWithHuman() {
	val h = Human()
	println("\nHuman Becomes Spiderman.....")
	h.power = Spiderman()
	h.fly()
	h.saveWorld()

	println("\nHuman Becomes Superman.....")
	h.power = Superman()
	h.fly()
	h.saveWorld()

	println("\nHuman Becomes Batman.....")
	h.power = Batman()
	h.fly()
	h.saveWorld()

	println("\nHuman Becomes Ironman.....")
	h.power = Ironman()
	h.fly()
	h.saveWorld()

	println("\nHuman Becomes Wonderwoman.....")
	h.power = Wonderwoman()
	h.fly()
	h.saveWorld()
}

//_________________________________________________________________________________
// Delegation Design Pattern
//		Constructor Argument Will Be Supplied Which Will Act As Delegate
										//			i.e. power Is Delegate
class HumanBetter(var power: Superpower) : Superpower by power

//Compiler Will Generate Following Code For Above Single Quick Line Of Code
class HumanBetterGenerated(var power: Superpower) {
	// Delegating Capability To Fly and SaveWorld To Delegate i.e. power
	fun fly() 		{   power.fly()   }
	fun saveWorld() {   power.saveWorld()   }	
} 

fun playWithHumanBetter() {
	var h: HumanBetter

	println("\nHuman Becomes Spiderman.....")
	h = HumanBetter( Spiderman() )
	h.fly()
	h.saveWorld()

	println("\nHuman Becomes Superman.....")
	h = HumanBetter( Superman() )
	h.fly()
	h.saveWorld()

	println("\nHuman Becomes Batman.....")
	h = HumanBetter( Batman() )
	h.fly()
	h.saveWorld()

	println("\nHuman Becomes Wonderwoman.....")
	h = HumanBetter( Batman() )
	h.fly()
	h.saveWorld()
}

//_________________________________________________________________________________

fun main() {
	println("\nFunction: playWithHuman")
	playWithHuman()

	println("\nFunction: playWithHumanBetter")
	playWithHumanBetter()
}


