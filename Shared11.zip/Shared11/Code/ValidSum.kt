
package learnKotlin

// Write validSum Function
//  	Which Returns Valid Sum
//		Or Print Cann't Calculate Sum
// 			For Given A and B Values

fun validSum1(a: Int, b: Int) : Int {
	  var result : Int = 0

	  if (((b > 0) && (a > (Int.MAX_VALUE - b))) ||
	      ((b < 0) && (a < (Int.MIN_VALUE - b)))) {
	    	println("Cann't Calculate Sum For Given A and B")
	  } else {
	    	result = a + b;
	  }

	  return result;
}

// Write validSum Function
//  	Which Returns Valid Sum Or
//		Or Returns Invalid Values When Sum Calculation Not Possible

fun validSum2(a: Int, b: Int) : Int? {
	  var result : Int? = null

	  if (((b > 0) && (a > (Int.MAX_VALUE - b))) ||
	      ((b < 0) && (a < (Int.MIN_VALUE - b)))) {
	    	// println("Cann't Calculate Sum For Given A and B")
	  		return result
	  } else {
	    	result = a + b;
	  }

	  return result;
}

fun playWithValidSum() {
	val a: Int = 2147483647
	val b: Int = 111

	val result1 = validSum1(a, b)
	println("Result : $result1")

	val result2 = validSum2(a, b)
	println("Result : $result2")
}

fun main() {
	println("\nFunction: playWithValidSum")
	playWithValidSum()
}

