package learnJava;

// Singleton Class: Class Having Only One Instance
class India { 
	// Member Variable To Track Single Instance Created For This Type/Class
	private static India indiaCountry;
	
	private String continent;
	private long area;

	// Constructor Private: Hide It Such That No One Else Can Use To Construct Instance
	private India() {
		continent = "Asia";
		area = 90909090;
	}
	
	// Type/Class Function: To Get Same Instance Always
	public static India getNationInstance() {
		if (indiaCountry == null)  {
			indiaCountry = new India();
		}
		return indiaCountry;
	}

	public long getArea() 			{ return area; 		}
	public String getContinent()	{ return continent; } 
}

public class Countries {
	public static void playWithIndia() {
		// India indiaCountry = new India();
		India indiaCountry = India.getNationInstance();
		System.out.println("India's Continent: " + indiaCountry.getContinent() );
		System.out.println("India's Areas: " + indiaCountry.getArea() );

		// India indiaCountry1 = new India();
		India indiaCountry1 = India.getNationInstance();
		System.out.println("India's Continent: " + indiaCountry1.getContinent() );
		System.out.println("India's Areas: " + indiaCountry1.getArea() );

		if ( indiaCountry == indiaCountry1 ) {
			System.out.println("Both References Are Pointing To Same Instance");
			System.out.println(indiaCountry);
			System.out.println(indiaCountry1);
		}
	}

	public static void main(String[] args) {
		System.out.println("\nFunction : playWithIndia");
		playWithIndia();
	}
}

