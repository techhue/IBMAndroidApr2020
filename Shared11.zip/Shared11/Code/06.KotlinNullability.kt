
package learnKotin

fun playWithNullability( ) {
	// Non Nullable Type
	//		It Stores ONLY Valid Values
	//		It's Default
	//
	var nonNullableString: String = "Hello World!"
	// Following Code Will Give Error
	// someString = null
	println(nonNullableString)

	// Nullable Type
	// 		Will Store Valid Value 
	// 		or Not A Valid Value
	//			Represeted By null
	
	// Nullable String
	//Can store null value in nullableString Variable
	var nullableString: String? = null
	
	println(nullableString)
	nullableString = "Hello World!"
	println(nullableString)
}

fun playWithNullability1() {
	var something: Int? = 30
	println(something)

	// println(something + 1)
	// error: operator call corresponds to a dot-qualified call 'something.plus(1)' which is not allowed on a nullable receiver 'something'.

	// println(something.plus(1))
	 //error: only safe (?.) or non-null asserted (!!.) calls are allowed on a nullable receiver of type Int?
	
	println(something?.plus(1))
	
	// something = null
	// NOT RECOMMENDED TO USE !! Operator
	// println(something!! + 1) // Will Give NullPointerException

	// ?: is Elvis Operator 
	var somethingValue = something ?: 0 // Default Value
	println(somethingValue + 1)

	something = null
	somethingValue = something ?: 0 // Default Value
	println(somethingValue + 1)
	// Above Line of Code is Equivalent To
	somethingValue = if (something != null ) something else 0
	println(somethingValue + 1)

}

// Expr is Type
interface Expr

// Num is Type of Expr
class Num(val value: Int) : Expr

// Sum is Type of Expr
class Sum(val left: Expr, val right: Expr) : Expr

// Type of e is Expr
fun eval(e: Expr): Int {
	
	// Type of e is Expr
	// is Does Type Check
	// e is of Type Num and If It is True
	//		Will Type Cast e to Num Type
    if (e is Num) { // Smart Type Check and Type Cast
    	// Type of e Will Be Num Type
        return e.value
    }

	// Type of e is Expr
	// is Does Type Check
	// e is of Type Sum and If It is True
	//		Will Type Cast e to Sum Type
    if (e is Sum) {
    	// Type of e Will Be Sum Type
        return eval(e.right) + eval(e.left)
    }

    throw IllegalArgumentException("Unknown expression")
}

fun playWithEvalIf() {
	println( eval( Sum( Num(10), Num(30) ) ) )
	println( eval( Sum( Sum( Num(10), Num(30) ), Num(100) ) ) )
}

fun main() {
	println("\nFunction: playWithNullability")
	playWithNullability()

	println("\nFunction: playWithNullability1")
	playWithNullability1()

	println("\nFunction: playWithEvalIf")
	playWithEvalIf()
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

