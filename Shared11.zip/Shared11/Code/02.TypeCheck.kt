
package learnKotlin

// Person Class With Two Properties [Name and isMarried]
	// val means Immutable: name is Constant
	// var means Variable: isMarried can be changed

// In Kotlin: Person Class
// 		It will Generate Constructor with 2 Arugments
//		It will Generate Instance Members for name and isMarried
//		It will Generate Getter and Setters for name and isMarried

class Person(val name: String, var isMarried: Boolean)

fun playWithPerson() {
	// Created person Object of Type Person
	val person = Person("Rajnikant", true)
	person.isMarried = false
	println(person.name)
	println(person.isMarried)
}

// rollno, name and age are Member Properties
// 		means Properties Consist of Member Variable and Getter/Setter

class Student(val rollno: Int, val name: String, var age: Int)

// Above Line of Code Generates Following Things
// 1. Student Class Constructor with 3 Arugments
//		Student(Int, String, Int)
// 2. Instance Members rollno, name and age
// 3. For IMMUTABLE PROPERTIES rollno, name only getter generated
		// i.e. 2 getters
// 4. For MUTABLE PROPERTY age both getter and setter generated
		// i.e. 1 getter and 1 setter

fun playWithStudent() {
	val supriya = Student(1, "Supriya", 22)
	println("${supriya.rollno}")
	println("${supriya.name}")
	println("${supriya.age}")
}

//______________________________________________________________________

interface Expr
class Num(val value: Int) : Expr
class Sum(val left: Expr, val right: Expr) : Expr

fun evalAgain(e: Expr): Int {
	// val something: Num = e as Num // error: unresolved reference: value
	val something1: Sum = e as Sum

	    
    // print(something.value)
    // return something.value

    // print(something1.value)
    // return something1.value
    // return e.value // error: unresolved reference: value

    print(something1.left)
    print(something1.right)
    
	// return eval(e.right) + eval(e.left)
	return 10;
}

fun playWithEvalAgain() {
	println( evalAgain( Sum( Num(10), Num(30) ) ) )
	println( evalAgain( Sum( Sum( Num(10), Num(30) ), Num(100) ) ) )
}

//______________________________________________________________________
fun eval(e: Expr): Int {
    // e Can Be Expr, Sum or Num Type

    // First Check Specific Type
    if (e is Num) {
    	// What Type e Will Here Num Type
    	// val tempE: Num = e as Num  // This Line Can Skipped
    	// return tempE.value
        return e.value
    }

    // e Can Be Expr, Sum or Num Type
    if (e is Sum) {
    	// What Type e Will Here Sum Type

    	// val tempE = e as Sum  // This Line Can Skipped
     	// return eval(tempE.right) + eval(tempE.left)

        return eval(e.right) + eval(e.left)
    }
    throw IllegalArgumentException("Unknown expression")
}

fun playWithEval() {
	println( eval( Sum( Num(10), Num(30) ) ) )
	println( eval( Sum( Sum( Num(10), Num(30) ), Num(100) ) ) )
}

//________________________________________________________

fun evalWhen(e: Expr): Int {
 	return when(e)  {
		is Num -> e.value
   		is Sum -> eval(e.right) + eval(e.left)
   		else   -> throw IllegalArgumentException("Unknown expression")
   	}
}

fun playWithEvalWhen() {
	println( evalWhen( Sum( Num(10), Num(30) ) ) )
	println( evalWhen( Sum( Sum( Num(10), Num(30) ), Num(100) ) ) )
}


//________________________________________________________

enum class Colour(var r: Int, val g: Int, val b: Int) {
	RED(255,0, 0), GREEN(0, 255, 0), BLUE(0, 0, 255),
	ORANGE(200, 100, 100), VIOLET(200, 0, 200), YELLOW(0, 200, 200),
	INDIGO(100, 100, 100)
	;

	// Member Function
	fun rgb(): Int {
		return (r * 256 + g) * 256 + b
	}
}

fun playWithColours() {
	// Accessing RED Colour
	println("Colour : ${Colour.RED}")
	println(Colour.RED.rgb())

	// Accessing Red Component of RED Colour
	println("Red Component 		: ${Colour.RED.r}" ) 
	
	// Accessing Green Component of RED Colour
	println("Green Component 	: ${Colour.RED.g}") 
	
	// Accessing Blue Component of RED Colour
	println("Blue Component 	: ${Colour.RED.b}") 
	
	println(Colour.BLUE)
	println(Colour.BLUE.rgb())
	println(Colour.BLUE.r)
	println(Colour.BLUE.g)
	println(Colour.BLUE.b)	

	println(Colour.ORANGE)
	println(Colour.ORANGE.rgb())

	println(Colour.VIOLET)
	println(Colour.VIOLET.rgb())
}

fun getColorNature(colour: Colour): String {
	return when(colour) {
		Colour.RED, Colour.ORANGE, Colour.YELLOW 	-> "Warm Colour"
		Colour.GREEN 								-> "Cold Colour"
		Colour.BLUE, Colour.VIOLET, Colour.INDIGO 	-> "Neutral Colour"
	}
}

//________________________________________________________

// Will Creates CIRCLE and SQUARE enum constants of Shape1 Type
enum class Shape1(val width: Double, val height: Double) {
	// Construtor is Common and Only One
	SQUARE(10.0, 10.0), RECTANGLE(40.9, 50.1)
}

fun shapeToString1(shape: Shape1): String {
	return when(shape) {
		Shape1.SQUARE 	 -> "Square Shape"
		Shape1.RECTANGLE -> "Rectangle Shape"
	}
}

fun playWithShapeToString1() {
	println(shapeToString1(Shape1.RECTANGLE))
	println(Shape1.RECTANGLE)
	println(Shape1.RECTANGLE.width)
	println(Shape1.RECTANGLE.height)
	
	println(shapeToString1(Shape1.SQUARE))
	println(Shape1.SQUARE)
	println(Shape1.SQUARE.width)
	println(Shape1.SQUARE.height)
}

// Sealed Classes Are Enums With Far More Flexibility
sealed class Shape2 {
 	// Following Nested Classes Have Different Constructors
  	class Square(val sideLength: Int): Shape2()
  	class Rectangle(val width: Int, val height: Int): Shape2()
  	class Circle(val radius: Int): Shape2()
}

fun shapeToString2(shape: Shape2): String {
	return when(shape) {
		is Shape2.Square 	 -> "Square Shape"
		is Shape2.Rectangle  -> "Rectangle Shape"
		is Shape2.Circle 	 -> "Circle Shape"
		// else -> "Unknown Shape"
	}
}

fun playWithShapeToString2() {
	val rect = Shape2.Rectangle(10, 20)
	println(shapeToString2(rect))
	println(rect)
	println(rect.width)
	println(rect.height)
	
	val square = Shape2.Square(90)
	println(shapeToString2(square))
	println(square)
	println(square.sideLength)

	val circle = Shape2.Circle(80)
	println(shapeToString2(circle))
	println(circle)
	println(circle.radius)
}

//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________

fun main() {
	println("\nFunction: playWithPerson")
	playWithPerson()

	println("\nFunction: playWithStudent")
	playWithStudent()

	// println("\nFunction: playWithEval")
	// playWithEval()

	println("\nFunction: playWithEvalAgain")
	playWithEvalAgain()
	
	println("\nFunction: playWithShapeToString1")
	playWithShapeToString1()

	println("\nFunction: playWithShapeToString2")
	playWithShapeToString2()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}
