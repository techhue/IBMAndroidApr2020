
package learnKotlin


//________________________________________________________

interface Clickable {
    fun click()
}

class Button : Clickable {
    override fun click() = println("I was clicked")
}

fun playWithButton() {
    val button = Button()
    button.click()
}

//________________________________________________________

interface Clickable1 {
    // Function Declaration : Abstract Method
    fun click()

    // Fuction Declaration and Definition : Concrete Method
    fun showOff() = println("I'm clickable!")
}

interface Focusable1 {
	// Fuction Declaration and Definition : Concrete Method
    fun setFocus(b: Boolean) = println("I ${if (b) "got" else "lost"} setFocus.")

	// Fuction Declaration and Definition : Concrete Method
    fun showOff() = println("I'm focusable!")
}

// Button1 Implementing Cliclable1 and Focusable1 Interfaces
// 		Implementing Means Can Provide 
//			Implementation Of Functions Declared/Defined In Clickable1/Focusable1
class Button1 : Clickable1, Focusable1 {
    override fun click() = println("I was clicked")

    // override fun showOff() = println("I'm Showing Off!!!")
    
    // Can Reuse Parent Type Implementation Also
    override fun showOff() {
    	super<Focusable1>.showOff()
    	super<Clickable1>.showOff()
    } 
}

fun playWithButton1() {
    val button = Button1()
    button.showOff()
    button.setFocus(true)
    button.click()
}

//________________________________________________________

// Intefaces Are Open By Default
// Interfaces Member Functions Are Also Open By Default
interface Clickable2 {
	// Abstract Method : Function is Declared But Not Defined
	fun click()

	// Concete Method : Function is Declared And Defined
	fun showOff() = println("I,m Clickable2!")
}

// Implementing Interface Clickable2
// In Kotlin : Classes Are Final By Default
//			   It CANN'T Be Subclassed
//		And It's Member Functions Are Also Final By Default
//			   It CANN'T Be Overriden

// In Java	 : Classes Are Open By Default
//			   It CAN Be Subclassed
//		And It's Member Functions Are Also Open By Default
//			   It CAN Be Overriden

open class Button2 : Clickable2 {
	// Abstract Method : Must Define It
	override fun click()   { println("Button2 : Click...")   }

	// Concete Method :  Can Be Redefined
	//		While Redefining Can Reuse Previous Implemenation
	override fun showOff()   { println("Button2 : Showoff...")   }

	// Member Methods Are Final By Default
	// Use open keyword to Open for Subclassing
	//		Note: Once Method is Open It's Open For Every Subclasses
	open fun disable() { println("Button2 : Disable...") }
	open fun animate() { println("Button2 : Animate...") }
}

// Inheritance By Extending Button2
//		Creating SubClass/SubType of Button2
open class FancyButton2 : Button2() {
	
	// click and disable Member Methods Are Open
	// Use final keyword to Disable for Subclassing
	//		Because: Once Method is Open It's Open For Every Subclasses
	final override fun click()   { println("FancyButton2 : Click...")   }
	
	override fun disable() { println("FancyButton2 : Disable...") }
	override fun animate() { println("FancyButton2 : Animate...") }
}

class SuperFancyButton2 : FancyButton2() {
	// override fun click()   { println("FancyButton2 : Click...")   } // Error
	override fun disable() { println("SuperFancyButton2 : Disable...") }

	override fun animate() { println("SuperFancyButton2 : Animate...") }
}

// 84:22: error: this type is final, so it cannot be inherited from
// class FancyButton2 : Button2 {
//                     ^
// 84:22: error: this type has a constructor, and thus must be initialized here

fun playWithButton2() {
    val button = Button2()
    button.click()
    button.showOff()

    val fancyButton = FancyButton2()
    fancyButton.click()
    fancyButton.click()
    fancyButton.showOff()

    val superFancyButton = SuperFancyButton2()
    superFancyButton.click()
    superFancyButton.click()
    superFancyButton.showOff()
}

//________________________________________________________

// Stored Properties
	// firstName and lastName
// Primary Constructor with 2 Arguments
//		Called Memberwise Intialiser
//			Because It Initialises All Stored Properties

data class Person1(var firstName: String, var lastName: String) {
	// Computed Property
	val fullName: String
		get() = "$firstName $lastName"
}

fun playWithPerson1() {
	// Primary Constructor
	// Calling Constructor To Create Object of Person Type
	val person1 = Person1(firstName = "Gabbar", lastName = "Singh")
	println( person1.fullName ) 
	
	val person2 = Person1(firstName = "Ram", lastName = "Singh")
	println( person2.fullName ) 

	val person3 = Person1(firstName = "Shyam", lastName = "Singh")
	println( person3.fullName ) 
}

fun playMoreWithPerson1() {
	//  Reference Assignment
	//	L.H.S means gabbar is reference to Object of Person1 Type
	//	Objects Are Stored At Heap
	//	Generally References Are Stored At Stack
	val gabbar = Person1(firstName = "Gabbar", lastName = "Singh")
	
	//  Reference Assignment
	val something = gabbar
	
	something.firstName = "Something"

	println( gabbar.fullName ) 
	println( something.fullName ) 
}

//________________________________________________________

fun playMoreWithPerson1Again() {
	val gabbar = Person1(firstName = "Gabbar", lastName = "Singh")
	val person1 = Person1(firstName = "Gabbar", lastName = "Singh")
	val person2 = Person1(firstName = "Ram", lastName = "Singh")	
	//  Reference Assignment
	val something = gabbar	

	// === Checks References Equality
	if (gabbar === something) { 
		println("Both Are References To Same Object")
	} else {
		println("Both Are References To Different Object")
	}
	
	if (gabbar === person1) {
		println("Both Are References To Same Object")
	} else {
		println("Both Are References To Different Object")
	}

	// == Checks Object Equality
	if (gabbar == person1) { 
		println("Both Objects Have Same Data")
	} else {
		println("Both Objects Have Different Data")
	}
	
	if (gabbar == person2) {
		println("Both Objects Have Same Data")
	} else {
		println("Both Objects Have Different Data")
	}
}

//________________________________________________________


class Person2(var firstName: String, var lastName: String) {
	// Computed Property
	val fullName: String
		get() = "$firstName $lastName"

	// equals() Function Comes From Parent Type
	//		In Java   : Every Class is Subclass of Object Type
	//		In Kotlin : Every Class is Subclass of Any Type
	// Defautl equal() Function Checks References Only By Default
	// Override equals() Function To Do Complete Object Comparisson
	// 		Operator == will get translated to equals() Function Call

	override fun equals(other: Any?): Boolean { 
		val person: Person2? = other as Person2?
		println("equals() FUNCTION CALLED....")
		return (person?.firstName == firstName && person?.lastName == lastName)
	}

	// toString() Function Comes From Parent Type
	//		In Java   : Every Class is Subclass of Object Type
	//		In Kotlin : Every Class is Subclass of Any Type
	// Default toString() Function Prints Type Of Object with Address
	// Override toString() Function To Print Complete Object
	//		i.e. Data Stored In Properties

	override fun toString(): String {
		println("ToString() FUNCTION CALLED....")
		return "Person2(firstName=$firstName, lastName=$lastName)"
	}
}

fun playMoreWithPerson2() {
	val gabbar = Person2(firstName = "Gabbar", lastName = "Singh")
	val samba = Person2(firstName = "Shamba", lastName = "Singh")
	val ram = Person2(firstName = "Ram", lastName = "Singh")	

	println(gabbar)
	// Compiler Translate prinln(gabbar) To Following Code
			// println(gabbar.toString())
	println(samba)
	// Compiler Translate prinln(samba) To Following Code
		// println(samba.toString())
	println(ram)

	val gabbarAgain = Person2(firstName = "Gabbar", lastName = "Singh")
	val sambaAgain = Person2(firstName = "Shamba", lastName = "Singh")
	val ramAgain = Person2(firstName = "Ram", lastName = "Singh")	
	println(gabbarAgain)
	println(sambaAgain)
	println(ramAgain)

	// == Checks Object Equality Provided It's Overriden
	//		Othewise It Will Compare Only References
	if (gabbar == gabbarAgain) { 
		println("Both Objects Have Same Data")
	} else {
		println("Both Objects Have Different Data")
	}
	
	if (samba == sambaAgain) {
		println("Both Objects Have Same Data")
	} else {
		println("Both Objects Have Different Data")
	}

	if (samba == ram) {
		println("Both Objects Have Same Data")
	} else {
		println("Both Objects Have Different Data")
	}

// Following Output For Default equals() method From Any/Object Type
// Default equals() Function Comapres References Only
	// Both Objects Have Different Data
	// Both Objects Have Different Data
	// Both Objects Have Different Data

// Following Output For Overriden equals() method
	// Both Objects Have Same Data
	// Both Objects Have Same Data
	// Both Objects Have Different Data
}

//________________________________________________________

// Data Classes : Will Generate Following Three Functions
// 		equals() Function Generated
//		hasCode() Function
// 		toString() Function

data class Person3(var firstName: String, var lastName: String) {
	// Computed Property
	val fullName: String
		get() = "$firstName $lastName"

	// Compiler Will Generate Following Functions
	// 		equals() Function Generated
	//				To Compare All Stored Properties of Class
	//		hasCode() Function
	//				Will Caculate HashCode Based On
	//				All Stored Properties of Class
	// 		toString() Function
	//				Will Print All Stored Properties's Values
}

fun playMoreWithPerson3() {
	val gabbar = Person3(firstName = "Gabbar", lastName = "Singh")
	val samba = Person3(firstName = "Shamba", lastName = "Singh")
	val ram = Person3(firstName = "Ram", lastName = "Singh")	

	println(gabbar)
	// Compiler Translate prinln(gabbar) To Following Code
			// println(gabbar.toString())
	println(samba)
	// Compiler Translate prinln(samba) To Following Code
		// println(samba.toString())
	println(ram)

	val gabbarAgain = Person3(firstName = "Gabbar", lastName = "Singh")
	val sambaAgain = Person3(firstName = "Shamba", lastName = "Singh")
	val ramAgain = Person3(firstName = "Ram", lastName = "Singh")	
	println(gabbarAgain)
	println(sambaAgain)
	println(ramAgain)

	if (gabbar == gabbarAgain) { 
		println("Both Objects Have Same Data")
	} else {
		println("Both Objects Have Different Data")
	}
	
	if (samba == sambaAgain) {
		println("Both Objects Have Same Data")
	} else {
		println("Both Objects Have Different Data")
	}

	if (samba == ram) {
		println("Both Objects Have Same Data")
	} else {
		println("Both Objects Have Different Data")
	}
}

//________________________________________________________

data class Person4(
	val firstName: String,
	val lastName: String) 
	// val firstName: String,
	// val lastName: String) 
{
	val fullName: String
		get() = "$firstName $lastName"
}

fun playWithMutabilityImmutability1() {
	// Immutable
	var gabbar = Person4(firstName = "Gabbar", lastName = "Singh")
	
	// Mutable
	var samba  = Person4(firstName = "Shamba", lastName = "Singh")
	println(gabbar)
	println(samba)

	gabbar = Person4(firstName = "Ding", lastName = "Dong") // Error
	
	// gabbar.firstName = "Something"
	// gabbar.lastName  = "Singhania"
	
	println(gabbar)

	samba  = Person4(firstName = "Ting", lastName = "Tong")
	println(samba)
}

//________________________________________________________

data class Grade(val letter: String, val points: Double, val credits: Double)

data class Student(
    val firstName: String,
    val lastName: String,
    // grade is Mutable or Immutable?
    val grades: MutableList<Grade> = mutableListOf(),
    var cumulativeCredits: Double = 0.0) 
{
	fun recordGrade(grade: Grade) {
	    grades.add(grade)
	    cumulativeCredits += grade.credits
	}
}

fun playWithMutabilityImmutability2() {
	// jane is Mutable or Immutable?
	val jane = Student(firstName = "Jane", lastName = "Appleseed")
	println(jane.grades)

	val history = Grade(letter = "B", points = 9.0, credits = 3.0)
	val math = Grade(letter = "A", points = 16.0, credits = 4.0)
	
	jane.recordGrade(history)
	jane.recordGrade(math)
	
	println(jane.grades)
	println(jane)
}

fun playWithMutabilityImmutability3() {
	// jane is Mutable or Immutable?
	val jane = Student(firstName = "Jane", lastName = "Appleseed")
	val history = Grade(letter = "B", points = 9.0, credits = 3.0)
	val math = Grade(letter = "A", points = 16.0, credits = 4.0)
	
	jane.recordGrade(history)
	jane.recordGrade(math)
	println(jane)

	println()
	
	val something = jane
	val science = Grade(letter = "A", points = 10.0, credits = 3.5)
	something.recordGrade(science)
	println(something)
	println(jane)
}

//________________________________________________________

data class Car(val name: String, val brand: String, val model: String, val chassiNumber: Int)

// Singleton Class
// 		A Class Having Only One Instance Possible
// object Class is Singleton Class
//		Instance of This Class Will Be Name Of The Class
object CarFactory {
	val company: String = "Maruti-Suzuki"
	val location: String = "Noida"
	val carsCreated = mutableListOf<Car>()

	fun createCar(name: String, model: String, chassiNumber: Int): Car {
		val car = Car(name, company, model, chassiNumber)
		carsCreated.add(car)
		return car
	}
}

object CarRepository {
	val cars = mutableListOf<Car>()
	fun addCar(member: Car) 	{ cars.add(member) }
	fun removeCar(member: Car) 	{ cars.remove(member) }
	
	fun listAll() {
		for ( car in cars ) {
			println("${car.name}, ${car.brand}, ${car.model}, ${car.chassiNumber}")
		}
	}
}

fun playWithCarFactory() {
	// val factory = CarFactory("Maruti-Suzuki", "Noida")
	// val factory1 = CarFactory("Maruti-Suzuki", "Noida")

	var car = CarFactory.createCar("Swift", "Desire", 90909)
	CarRepository.addCar(car)
	car = CarFactory.createCar("Swift", "Desire", 90910)
	CarRepository.addCar(car)
	car = CarFactory.createCar("Swift", "Desire", 90911)
	CarRepository.addCar(car)
	car = CarFactory.createCar("Swift", "Desire", 90912)
	CarRepository.addCar(car)
	car = CarFactory.createCar("Alto", "HatchBack", 70909)
	CarRepository.addCar(car)
	car = CarFactory.createCar("Alto", "HatchBack", 70910)
	CarRepository.addCar(car)
	car = CarFactory.createCar("Celario", "Sedan", 80909)
	CarRepository.addCar(car)
	car = CarFactory.createCar("Celario", "Sedan", 80910)
	CarRepository.addCar(car)

	CarRepository.listAll()
}

//________________________________________________________

// Object Class: Singleton Class Having Only One Instance
//		And Name of Instance Will Be Same As Class Name

object India { 
	val continent: String = "Asia"
	val area: Long = 90909090
	
	// private String continent;
	// private long area;

	// private static India indiaCountry;

	// // Constructor Private: Hide It Such That No One Else Can Use To Construct Instance
	// private India() {
	// 	continent = "Asia";
	// 	area = 90909090;
	// }
	
	// // Type/Class Function: To Get Same Instance Always
	// public static India getNationInstance() {
	// 	if (indiaCountry == null)  {
	// 		indiaCountry = new India();
	// 	}
	// 	return indiaCountry;
	// }

	// public long getArea() 			{ return area; 		}
	// public String getContinent()	{ return continent; } 
}

//________________________________________________________

fun playWithIndia() {
	println(India.area)
	println(India.continent)
}

//________________________________________________________

class Scientist private constructor(val id: Int, val firstName: String, val lastName: String) {
	companion object Create {
		var currentID = 0
		fun newScientist(firstName: String, lastName: String): Scientist {
			currentID += 1
			return Scientist(currentID, firstName, lastName)
		}
	}
	var fullName = "$firstName $lastName"
}

object ScientistRepository {
	val scientists = mutableListOf<Scientist>()

	fun addScientist(member: Scientist) {
		scientists.add(member)
	}

	fun removeScientist(member: Scientist) {
		scientists.remove(member)
	}

	fun listAll() {
		for ( scientist in scientists ) {
			println("${scientist.id}, ${scientist.fullName}")
		}
	}
}

fun playWithScientist() {
	// var someone = Scientist(90, "Abdul", "Kalam")	
	val raman = Scientist.newScientist("C V", "Raman")
	val saha = Scientist.newScientist("Meghnath", "Saha")
	val bose = Scientist.newScientist("S N", "Bose")
	val bose1 = Scientist.Create.newScientist("J C", "Bose")
	ScientistRepository.addScientist(raman)
	ScientistRepository.addScientist(saha)
	ScientistRepository.addScientist(bose)
	ScientistRepository.addScientist(bose1)
	ScientistRepository.listAll()
}

//________________________________________________________

class Person5 {
	// Memebers With Default Values
	var firstName: String = ""
	var lastName: String = ""
	var city: String = ""
	
	//Memebers Without Default Values
	var state: String
	var country: String

	val fullName: String
		get() = "$firstName $lastName"

	init {
		state = ""
		country = ""
	}
}

fun playMoreWithPerson5() {
	var person1 = Person5()
	println(person1)
}

//________________________________________________________

class InternationalSpaceStation {
	var orbitalSpeed: Float = 7.66F

	fun flyAroundEarth() {
		println("Fly Around Earth! with Orbital Speed: $orbitalSpeed")
	}
}

fun playWithInternationalSpaceStationDuplicates() {
	// val issExists = false
	val iss: InternationalSpaceStation

		iss = InternationalSpaceStation()
		iss.flyAroundEarth()

	// if ( !issExists ) {
	// 	iss = InternationalSpaceStation()
	// 	iss.flyAroundEarth()
	// } else {
	// 	iss.flyAroundEarth()
	// }

	val iss1 = InternationalSpaceStation()
	iss1.flyAroundEarth()

	if (iss === iss1 ) {
		println("Both Are SAME ISS")
	} else {
		println("Both Are DIFFERENT ISS")
	}
}

//________________________________________________________

// Singleton Design Pattern: 
//		It's Code Design To Solve Particular Problem
//		To Have Only One Instance
// object Class Is A Singleton Class
//		It's ONLY One Object Exists
//		Object Name and Class Name Will Be Same
//	Internally It will Generate Following Things
//		Makes Constructor Private
//		Makes One Instance Member To Store ONLY ONE Instance of This Type/Class
//			This Instance Can Be Accessed Using Type/Class Name

object InternationalSpaceStationSingleton {
	var orbitalSpeed: Float = 7.66F

	fun flyAroundEarth() {
		println("Fly Around Earth! with Orbital Speed: $orbitalSpeed")
	}
}

fun playWithInternationalSpaceStationSingleton() {
	// val iss = InternationalSpaceStationSingleton() // Error Because Constructor is Private
	//error: expression 'InternationalSpaceStationSingleton' of type 'InternationalSpaceStationSingleton' cannot be invoked as a function. The function 'invoke()' is not found

	InternationalSpaceStationSingleton.flyAroundEarth()
}

//________________________________________________________

// Custom Accessors: Setter and Getter
class Rectangle1(val height: Int, val width: Int) {
    val isSquare: Boolean
        get() {
            return height == width
        }
}

fun playWithRectangle1() {
    val rectangle = Rectangle1(41, 43)
    println(rectangle.isSquare)
}

class Rectangle2(var width: Double, var height: Double) {
    val isSquare: Boolean
        get() {	return height == width }

	val area: Double
		get() { return width * height }

	var xCoordinate: Double = 0.0
		set(newX) {  xCoordinate = newX  }

	var yCoordinate: Double = 0.0
		set(newY) {	 yCoordinate = newY  }
}

// Extension Property On Type/Class
val Rectangle2.perimeter: Double
	get() = 2 * (width + height)

// Extension Function On Type/Class
fun Rectangle2.draw() {
	println("Drawing Rectangle2...")
}

fun playWithRectangle2() {
	val rect = Rectangle2(10.0, 20.0)
	val area = rect.area
	val xCoord = rect.xCoordinate
	val yCoord = rect.yCoordinate

	println("Areas	: $area ")
	println("Center : ($xCoord, $yCoord)")

	val peri = rect.perimeter
	println("Perimeter : $peri ")
	rect.draw()
}



//________________________________________________________

data class LightBulb(val watt: Int)

class Lamp(var type: String) {
	lateinit var bulb: LightBulb
}

fun playWithLamp() {
	val lamp = Lamp("WallMounted")
	
	println(lamp)
	// println(lamp.bulb)
 	//kotlin.UninitializedPropertyAccessException: lateinit property bulb has not been initialized

	lamp.bulb = LightBulb(100)
	println(lamp.bulb)
}

//________________________________________________________

class Scientist1(val id: Int, val firstName: String, val lastName: String) {
	var lab: String = ""
	companion object {
		var currentID = 0
		fun newScientist(firstName: String, lastName: String): Scientist1 {
			currentID += 1
			return Scientist1(currentID, firstName, lastName)
		}
	}
	var fullName = "$firstName $lastName"
}

// Extension Property On Companion Object 
val Scientist1.Companion.id: Int
	get() = currentID

// Extension Function On Companion Object 	    
fun Scientist1.Companion.expertise(): String {
	return "Expertise Yet To Be Assigned..."
}

fun playWithScientist1() {
	var expertise: String
	val raman = Scientist.newScientist("C V", "Raman")
	val saha = Scientist.newScientist("Meghnath", "Saha")

	println(" Name : ${raman.fullName}")
	println(" ID: ${raman.id}")
	expertise = Scientist1.expertise()
	println(" Expertise: ${expertise}")

	println(" Name : ${saha.fullName}")
	println(" ID: ${saha.id}")
	expertise = Scientist1.expertise()
	println(" Expertise: ${expertise}")
}

//________________________________________________________

interface Clickable9 {
	fun click()
	fun showOff() = println("I,m Clickable2!")
}

open class Button9 : Clickable9 {
	override fun click()   { println("Button9 : Click...")   }
	override fun showOff()   { println("Button9 : Showoff...")   }
	open fun disable() { println("Button9 : Disable...") }
	open fun animate() { println("Button9 : Animate...") }
}

open class FancyButton9 : Button9() {
	final override fun click()   { println("FancyButton9 : Click...")   }
	override fun disable() { println("FancyButton9 : Disable...") }
	override fun animate() { println("FancyButton9 : Animate...") }
}

class SuperFancyButton9 : FancyButton9() {
	override fun disable() { println("SuperFancyButton9 : Disable...") }
	override fun animate() { println("SuperFancyButton9 : Animate...") }
}

fun playWithButton9() {
    var button: Button9
    var fancyButton = FancyButton9()
    var superFancyButton = SuperFancyButton9()

	// CANN'T Assign Parent Class Reference to Child Class Reference
	fancyButton = button
    println(button is Button9)
    println(button is FancyButton9)
    println(button is SuperFancyButton9)

    println(fancyButton is Button9)
    println(fancyButton is FancyButton9)
    println(fancyButton is SuperFancyButton9)

    println(superFancyButton is Button9)
    println(superFancyButton is FancyButton9)
    println(superFancyButton is SuperFancyButton9)
    println(superFancyButton !is Button9)

    // Can Assign Child Class Reference to Parent Class Reference
    button = fancyButton
    println(button)
    button = superFancyButton
    println(button)
    println(fancyButton)
    println(superFancyButton)
}

//________________________________________________________

fun main() {
	println("\nFunction: playWithButton")
	playWithButton()

	println("\nFunction: playWithButton1")
	playWithButton1()

	println("\nFunction: playWithButton2")
	playWithButton2()

	println("\nFunction: playWithPerson1")
	playWithPerson1()

	println("\nFunction: playMoreWithPerson1")
	playMoreWithPerson1()

	println("\nFunction: playMoreWithPerson1Again")
	playMoreWithPerson1Again()

	println("\nFunction: playMoreWithPerson2")
	playMoreWithPerson2()	
	
	println("\nFunction: playMoreWithPerson3")
	playMoreWithPerson3()

	println("\nFunction: playWithMutabilityImmutability1")
	playWithMutabilityImmutability1()

	println("\nFunction: playWithMutabilityImmutability2")
	playWithMutabilityImmutability2()

	println("\nFunction: playWithMutabilityImmutability3")
	playWithMutabilityImmutability3()
	
	println("\nFunction: playWithCarFactory")
	playWithCarFactory()
	
	println("\nFunction: playWithIndia")
	playWithIndia()
	
	println("\nFunction: playWithScientist")
	playWithScientist()

	println("\nFunction: playMoreWithPerson5")
	playMoreWithPerson5()

	println("\nFunction: playWithInternationalSpaceStationDuplicates")
	playWithInternationalSpaceStationDuplicates()

	println("\nFunction: playWithInternationalSpaceStationSingleton")
	playWithInternationalSpaceStationSingleton()

	println("\nFunction: playWithRectangle1")
	playWithRectangle1()

	println("\nFunction: playWithRectangle2")
	playWithRectangle2()

	println("\nFunction: playWithLamp")					
	playWithLamp()

	println("\nFunction: playWithScientist1")
	playWithScientist1()

	println("\nFunction: playWithButton9")					
	playWithButton9()

	println("\nFunction: playWithButton9Again")
	playWithButton9Again()

	// println("\nFunction: ")					
	// println("\nFunction: ")
	// println("\nFunction: ")					
}

