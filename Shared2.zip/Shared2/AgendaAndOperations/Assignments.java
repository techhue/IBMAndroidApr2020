
DAY 01
_____________________________________________________________
	
	READING ASSIGNMENT
	__________________________________________________________
		Data Type Chapter
			Programming In C, Kernigham and Denish Ritchie

	CODING AND PRACTICE ASSIGNMENTS
	__________________________________________________________
		Code and Practice Kotlin Code Shared


DAY 02
_____________________________________________________________

	CODING AND PRACTICE ASSIGNMENTS
	__________________________________________________________
		Code and Practice Kotlin Code Shared


DAY 03
_____________________________________________________________

	READING ASSIGNMENT
	__________________________________________________________
		Kotlin Notes 
			Expressions, Variables and Constants 
			Types and Operations 
			Basic Control Flow 
			Functions 

	CODING AND PRACTICE ASSIGNMENTS
	__________________________________________________________
		Kotlin Code Shared
			Revise and Practice
		Kotlin Notes Code 
			Type and Practice
		Kotlin Notes Assignments 
			Solve It

