package learnKotlin

fun incrementValue(value: Int) {
	// By Default Arguments of Function Are IMMUTABLE
	// value = value + 1   // error: val cannot be reassigned
	println(value) 
	
	val newValue = value + 1
	println(newValue)
}

// Function Overloading
//	 	Can Overload Function Based On Number of Arguments
//	 	Can Overload Function Based On Type of Arguments
// NOTE: Return Type Will Be Sufficient To Overload Functions

fun sum(x: Int, y: Int) = x + y
fun sum(x: Int, y: Int, z: Int) = x + y + z
fun sum(x: Float, y: Float) = x + y
fun sum(x: Float, y: Float, z: Float) = x + y + z


fun addition(a: Int, b: Int) : Int { return a + b }
fun substraction(a: Int, b: Int) : Int { return a - b }
fun multiplication(a: Int, b: Int) : Int { return a * b }
fun divison(a: Int, b: Int) : Int { return b / a }

fun addition3(a: Int, b: Int, c: Int) : Int { return a + b + c }

// Function is Variable
fun playWithFunctions() {
	val a = 101
	val b = 202
	var result: Int
	
	result = addition(a, b)
	println("addition Function Result: $result")

	// ::FUNCTION_NAME gives reference of Function
	// ::addition is Reference of Function addition
	// something is a Variable Which Is Storing Function
	
	// Type of somthing is Function 
	// 		Which Takes 2 Int Arguments and Return Int
	
	var something: (Int, Int) -> Int = ::addition
	
	result = something(a, b)
	println("something Result: $result")

	something = ::substraction
	result = something(a, b)
	println("something Result: $result")

	something = ::multiplication
	result = something(a, b)
	println("something Result: $result")

	//  error: type mismatch: inferred type is 
	//	KFunction3<@ParameterName Int, @ParameterName Int, @ParameterName Int, Int> 
	//	but (Int, Int) -> Int was expected
	
	// Error 
	// Trying To Assign A Function Which Takes (Int, Int, Int) -> Int
	//	To A Variable something Which Takes (Int, Int) -> Int
	// something = ::addition3 
}

// Calculator is a Function Which Takes 3 Arguments
//		First 2 Arguments Are Int Type
//		Last Argument Is Function Type (Int, Int) -> Int
//		Calculator Return Type Is Int

fun calculator(a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
	return operation(a, b)
}

fun playWithCalculator() {
	val a = 100
	val b = 20
	var result : Int 	

	result = calculator(a, b, ::addition)
	println("Result Is: $result")

	result = calculator(a, b, ::substraction)
	println("Result Is: $result")

	result = calculator(a, b, ::multiplication)
	println("Result Is: $result")
}


fun main() {
	println("\nFunction: incrementValue")
	incrementValue(1000)

	println("\nFunction: sum with 2 Int Arguments")
	println(sum(100, 200))

	println("\nFunction: sum with 3 Int Arguments")
	println(sum(100, 200, 300))

	println("\nFunction: sum with 2 Float Arguments")
	println(sum(10.9F, 20.9F))
	
	println("\nFunction: sum with 3 Float Arguments")
	println(sum(10.9F, 20.9F, 300.0F))

	println("\nFunction: playWithFunctions")
	playWithFunctions()

	println("\nFunction: playWithCalculator")
	playWithCalculator()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}
