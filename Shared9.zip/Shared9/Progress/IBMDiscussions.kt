

Type In Kotlin
_______________________________________________________
	1. Type Inferencing 
			Implicitly is Default
			Can Specify Explicitly Also
	2. Type Binding
	3. Value Storage

	// Compiler Will Try To Inference Type : Kotlin Style
	// 		If Not Specified Explicitly
	// Type In Kotlin
	// _______________________________________________________
	// 	1. Type Inferencing 
	// 			Implicitly is Default
	// 			Can Specify Explicitly Also
	// 	2. Type Binding
	// 	3. Value Storage

	val some 	= 10  			// Type : 

	// Explicit Types Assigned
	// Java/C/C++ Style

	val some1: Int 			= 10  			

	e.g.
	val ding3: Float 	= 90.10F
	// 	1. Type Inferenced Will Be Double
	// 	2. Type Binding Done Explicitly Float
	//	3. Value Storage In ding3
	
	// NOTE: In case Java/C/C++ 
		// Type Converstion of Value From Double To Float Will Happen
			// float ding3 	= 90.10

Nullability and NonNullability
_______________________________________________________
	In Kotlin By Default
		Types Are NonNullable
			You CANN'T Assign Null Value To Variables

	In Java/C/C++ By Default
		Types Are Nullable
			You CAN Assign Null Value To Variables

	Kotlin Style
		Design Towards Non-Nullability Rather Towards Nullability

Kotlin Classes Vs Java Classes
_______________________________________________________

// Person Class With Two Properties [Name and isMarried]
	// val means Immutable: name is Constant
	// var means Variable: isMarried can be changed

// In Kotlin: Person Class
// 		It will Generate Constructor with 2 Arugments
//		It will Generate Instance Members for name and isMarried
//		It will Generate Getter and Setters for name and isMarried

class Person(val name: String, var isMarried: Boolean)

// In Java: Person Class
// class Person {
//     private String name;
//     private Boolean isMarried;
    
// // Define Constructor and Constructor Body
//     public Person(String name,Boolean isMarried) {
//         this.name=name;
//         this.isMarried=isMarried;
//     }

// // Getter and Setters 
//     public String getName() {
//     	return name;
//     }

// 	public void setName(String name ) {
// 		this.name = name;
// 	}

// 	public Boolean getIsMarried() {
// 		return isMarried;
// 	}

// 	public void setIsMarried(Boolean isMarried) {
// 		this.isMarried = isMarried
// 	}
// }

fun playWithPersonProperties() {
	// Created person Object of Type Person
	val person = Person("Rajnikant", true)
	// Accessing Person Properties
	
	// Kotlin Compiler Will Generate Setter For MUTABLE Property
		// person.isMarried = false will be converted to
		//		person.setIsMarried(false)
	
	person.isMarried = false

	// Kotlin Compiler Will NOT Generate Setter For IMMUTABLE Property
	// person.name = "Kamal Hassan" // Error: Unmodifiable


	// Kotlin Compiler Will Generate Getters For 
	// 		Both MUTABLE and IMMUTABLE Properties

	// person.name  will get converted into person.getName()
	// person.isMarried will get converted into person.getIsMarried()

	println(person.name)
	println(person.isMarried)
}

// DO EXERCISE
//_____________________________________________________
// Write Person Class In Java
//		Person Has Two Properties Name and isMarried
//		And Able To Do All Above Functionality
// Run Java Code In Online Compiler
//	20 Mintutes I am giving
//_____________________________________________________



// public World {
// 	public static void main(String[] args) {
//         Person ob = new Person("Chinmaye", false);
        
//         System.out.println(ob.name);
//         System.out.println(ob.isMarried);
//     }
// }


