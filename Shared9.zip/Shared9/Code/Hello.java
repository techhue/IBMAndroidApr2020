/*
// Java Commands To Compile And Run Code
_____________________________________________
	javac Hello.java -d ClassFiles
	java -cp ClassFiles learnJava.Hello
*/

package learnJava;

public class Hello {
    public static void main(String[] args) {
    	String someString = new String("Hello World!!!");
    	someString = null;
        System.out.println( someString );

        // Always Check for Every Object for Not null Value
        if ( someString != null ) {
        	System.out.println( someString.toUpperCase() );
        } else {
        	System.out.println( "Nothingness Found!..." );
        }
    
	// Exception in thread "main" java.lang.NullPointerException
	// 	at learnJava.Hello.main(Hello.java:15)

    }
}


// Simulate Following Code In Java
// >>> var someString: String = "Hello World!"
// >>> someString
// res9: kotlin.String = Hello World!
// >>> 
// >>> 
// >>> someString = null
// error: null can not be a value of a non-null type String
// someString = null