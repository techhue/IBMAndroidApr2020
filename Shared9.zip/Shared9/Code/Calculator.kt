package learnKotlin

enum class Operation { ADDITION, SUBSTRACTION, MULTIPLICATION, DIVISION }

fun calculator(a: Int, b: Int, doOperation: (Int, Int) -> Int ) : Int {
	return doOperation(a, b)
}

// Improve Following Code To 
// Return Result Based On Choice Of Operation Supplied
fun doCalculation(a: Int, b: Int, choice: Operation) : Int {
	var doSomething: (Int, Int) -> Int

	// When is Expression in Kotlin: It has Return Value
	// Where as Switch is Statement in C/C++/Java
	// when (choice) {
	// 		  		// Lambda Expression Having Type (Int, Int) -> Int
	// 	Operation.ADDITION ->  doSomething = { x: Int, y: Int -> x + y } // Lambda To Do Addition
	// 				// Lambda Expression Having Type (Int, Int) -> Int
	// 	Operation.SUBSTRACTION -> doSomething = { x: Int, y: Int -> x - y } // Lambda To Do Substraction
	// 				// Lambda Expression Having Type (Int, Int) -> Int
	// 	Operation.MULTIPLICATION -> doSomething = { x: Int, y: Int -> x * y } // Lambda To Do Multiplication
	// 				// Lambda Expression Having Type (Int, Int) -> Int
	// 	Operation.DIVISION -> doSomething = { x: Int, y: Int -> x / y } // Lambda To Do Division	
	// }

	doSomething = when (choice) {
		Operation.ADDITION 		-> { x: Int, y: Int -> x + y } // Lambda To Do Addition
		Operation.SUBSTRACTION 	-> { x: Int, y: Int -> x - y } // Lambda To Do Substraction
		Operation.MULTIPLICATION-> { x: Int, y: Int -> x * y } // Lambda To Do Multiplication
		Operation.DIVISION 		-> { x: Int, y: Int -> x / y } // Lambda To Do Division	
	}

	return calculator(a, b, doSomething)
}

// Implement Following Functions Also
// fun doCalculation(a: Float, b: Float, choice: Operation) : Float { }
// fun doCalculation(a: Double, b: Double, choice: Operation) : Double { }

fun main() {
	val a = 200
	val b = 100
	var result1: Int
	
	result1 = doCalculation(a, b, Operation.ADDITION)
	println("Result : $result1")

	result1 = doCalculation(a, b, Operation.SUBSTRACTION)
	println("Result : $result1")

	result1 = doCalculation(a, b, Operation.MULTIPLICATION)
	println("Result : $result1")
}
