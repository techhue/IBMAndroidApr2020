
package learnKotlin


//________________________________________________________

interface Clickable {
    fun click()
}

class Button : Clickable {
    override fun click() = println("I was clicked")
}

fun playWithButton() {
    val button = Button()
    button.click()
}

//________________________________________________________

interface Clickable1 {
    // Function Declaration : Abstract Method
    fun click()

    // Fuction Declaration and Definition : Concrete Method
    fun showOff() = println("I'm clickable!")
}

interface Focusable1 {
	// Fuction Declaration and Definition : Concrete Method
    fun setFocus(b: Boolean) = println("I ${if (b) "got" else "lost"} setFocus.")

	// Fuction Declaration and Definition : Concrete Method
    fun showOff() = println("I'm focusable!")
}

// Button1 Implementing Cliclable1 and Focusable1 Interfaces
// 		Implementing Means Can Provide 
//			Implementation Of Functions Declared/Defined In Clickable1/Focusable1
class Button1 : Clickable1, Focusable1 {
    override fun click() = println("I was clicked")

    // override fun showOff() = println("I'm Showing Off!!!")
    
    // Can Reuse Parent Type Implementation Also
    override fun showOff() {
    	super<Focusable1>.showOff()
    	super<Clickable1>.showOff()
    } 
}

fun playWithButton1() {
    val button = Button1()
    button.showOff()
    button.setFocus(true)
    button.click()
}

//________________________________________________________

// Intefaces Are Open By Default
// Interfaces Member Functions Are Also Open By Default
interface Clickable2 {
	// Abstract Method : Function is Declared But Not Defined
	fun click()

	// Concete Method : Function is Declared And Defined
	fun showOff() = println("I,m Clickable2!")
}

// Implementing Interface Clickable2
// In Kotlin : Classes Are Final By Default
//			   It CANN'T Be Subclassed
//		And It's Member Functions Are Also Final By Default
//			   It CANN'T Be Overriden

// In Java	 : Classes Are Open By Default
//			   It CAN Be Subclassed
//		And It's Member Functions Are Also Open By Default
//			   It CAN Be Overriden

open class Button2 : Clickable2 {
	// Abstract Method : Must Define It
	override fun click()   { println("Button2 : Click...")   }

	// Concete Method :  Can Be Redefined
	//		While Redefining Can Reuse Previous Implemenation
	override fun showOff()   { println("Button2 : Showoff...")   }

	// Member Methods Are Final By Default
	// Use open keyword to Open for Subclassing
	//		Note: Once Method is Open It's Open For Every Subclasses
	open fun disable() { println("Button2 : Disable...") }
	open fun animate() { println("Button2 : Animate...") }
}

// Inheritance By Extending Button2
//		Creating SubClass/SubType of Button2
open class FancyButton2 : Button2() {
	
	// click and disable Member Methods Are Open
	// Use final keyword to Disable for Subclassing
	//		Because: Once Method is Open It's Open For Every Subclasses
	final override fun click()   { println("FancyButton2 : Click...")   }
	
	override fun disable() { println("FancyButton2 : Disable...") }
	override fun animate() { println("FancyButton2 : Animate...") }
}

class SuperFancyButton2 : FancyButton2() {
	// override fun click()   { println("FancyButton2 : Click...")   } // Error
	override fun disable() { println("SuperFancyButton2 : Disable...") }

	override fun animate() { println("SuperFancyButton2 : Animate...") }
}

// 84:22: error: this type is final, so it cannot be inherited from
// class FancyButton2 : Button2 {
//                     ^
// 84:22: error: this type has a constructor, and thus must be initialized here

fun playWithButton2() {
    val button = Button2()
    button.click()
    button.showOff()

    val fancyButton = FancyButton2()
    fancyButton.click()
    fancyButton.click()
    fancyButton.showOff()

    val superFancyButton = SuperFancyButton2()
    superFancyButton.click()
    superFancyButton.click()
    superFancyButton.showOff()
}

//________________________________________________________

// Stored Properties
	// firstName and lastName
// Primary Constructor with 2 Arguments
//		Called Memberwise Intialiser
//			Because It Initialises All Stored Properties

class Person1(var firstName: String, var lastName: String) {
	// Computed Property
	val fullName: String
		get() = "$firstName $lastName"

		// get() {
		// 	return "$firstName $lastName"
		// }
}

fun playWithPerson1() {
	// Primary Constructor
	// Calling Constructor To Create Object of Person Type
	val person1 = Person1(firstName = "Gabbar", lastName = "Singh")
	println( person1.fullName ) 
	
	val person2 = Person1(firstName = "Ram", lastName = "Singh")
	println( person2.fullName ) 

	val person3 = Person1(firstName = "Shyam", lastName = "Singh")
	println( person3.fullName ) 
}

fun playMoreWithPerson1() {
	//  Reference Assignment
	//	L.H.S means gabbar is reference to Object of Person1 Type
	//	Objects Are Stored At Heap
	//	Generally References Are Stored At Stack
	val gabbar = Person1(firstName = "Gabbar", lastName = "Singh")
	
	//  Reference Assignment
	val something = gabbar
	
	something.firstName = "Something"

	println( gabbar.fullName ) 
	println( something.fullName ) 
}

//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________

fun main() {
	println("\nFunction: playWithButton")
	playWithButton()

	println("\nFunction: playWithButton1")
	playWithButton1()

	println("\nFunction: playWithButton2")
	playWithButton2()

	println("\nFunction: playWithPerson1")
	playWithPerson1()

	println("\nFunction: playMoreWithPerson1")
	playMoreWithPerson1()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

