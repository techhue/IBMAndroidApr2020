#include <stdio.h>

int main() {
	int x = 0;
	int y = 0;

	// Code Sample 1: Using if-else 
	if (x == 10) {
		y = 100;
	} else {
		y = 200;
	}

	printf("\nY Value: %d", y );
	
	
	//Is Following Possible In C/C++/Java???
	// error: expected expression
	// 		On RHS You Can ONLY Supply Expression
	y = if (x == 10) { 100; } else { 200; }

	// Code Sample 2: Using Terniary Operator

	//Logically Both Code Sample Are Same
	// In C/C++/Java
	// Terniary Operator Statement is Expression
	y = (x == 10) ? 100 : 200; 
	printf("\nY Value: %d", y );

}
