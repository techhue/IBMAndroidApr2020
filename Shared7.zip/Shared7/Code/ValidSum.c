
// VALID SUM
#include <limits.h>
  
signed int sum(signed int a, signed int b) {
	  signed int result = 0;

	  if (((b > 0) && (a > (INT_MAX - b))) ||
	      ((b < 0) && (a < (INT_MIN - b)))) {
	   		printf("Cann't Calcualte Sum For These A and B Values\n", );
	  } else {
		    result = a + b;
	  }
	  
	  return result;
	  /* ... */
}
