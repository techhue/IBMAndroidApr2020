// Nandini's

fun sum(x: Int, y: Int) : Int { 
    var result : Int
    result= x+y;
    return result;
}

fun main() {
    val a: Int=2147483647
    val b: Int=111
    if((a<2147483647&&a>(-2147483648)) && (b <2147483647 && a>(-2147483648))) {
    var result : Int = sum(a,b)
    println(""Result : $result"");
    }
    else 
    {
    println(""cannot calculate sum for given x and y"")
    }
}

//_______________________________________________________________________

// Chinmaye

#include<stdio.h>
 
int main() {
   unsigned int x, y,res;
   
 
   printf(""\nEnter the two numbers : "");
   scanf(""%u %u"", &x, &y);
 
   res = sum(x, y);
   
   if(res==sizeof(unsigned int)){
   printf(""Addition of two number is :%u "",res);
   }else{
    printf(""not found.."");
   }
   

}
 
   int sum(unsigned int x,unsigned int y) {
   int z;
   z= x + y;
   return (z);
}

// _______________________________________________________________________

// Dharani

#include<stdio.h>
int main(){
    
    int result=sum(5,4);
    printf(""Sum:%d"",result);
    int result1=sum(90909090909090111,100000000000000111);
     printf(""\nSum:%d"",result1);
}

int sum(int x, int y){
        int z=x+y;
        if(sizeof(z)==sizeof(int))
        {
        return z;
        }
        else{
            printf(""Can find sum of these numbers"");
        }
    
    }

// _______________________________________________________________________

// Nidhi

#include <stdio.h>

long int sum(long int x, long int y ){
    long int c=x+y;
    printf (""%ld"",c);
    }
    long int main(){
        sum(909090909011,100000000011);
    }


package learnKotlin;

fun sum(x: Int,y:Int):Int{
    var result:Int
    result = x+y
    return result
}

fun main(){
    val a=2147483647
    val b=111

    var result:Int=sum(a,b)
    println(""Result: $result"")
}


//_______________________________________________________________________

// Sherya

#include<stdio.h>
int main(){
    
    int result=sum(67,3);
    printf(""Sum:%d"",result);
    int result1=sum(909090909090,100000000111);
     printf(""\nSum:%d"",result1);
}

int sum(int a, int b){
        int x=a+b;
        if(sizeof(x)==sizeof(int))
        {
        return x;
        }
        else{
            printf(""Can find sum of these numbers"");
        }
    
}

//_______________________________________________________________________

// Triveni

package learnKotlin;

fun sum(x: Int,y:Int):Int{
    var result:Int
    result = x+y
    return result
}

fun main(){
    val a=2147483647
    val b=111

    var result:Int=sum(a,b)
    println(""Result: $result"")
}

