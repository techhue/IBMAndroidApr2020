
package learnKotlin

// Write Sum Function
//  	Which Returns Valid Sum
//		Or Print Cann't Calculate Sum
// 			For Given X and Y Values

// Fuction Type Must Be: (Int, Int) -> Int
fun sum(x: Int, y: Int): Int {
	var result: Int;
	result = x + y;
	return result;
}

fun main() {
	// val a: Int = 90909090909090111;
	// val b: Int  = 10000000000000111;

	val a: Int = 2147483647;
	val b: Int = 1;

	var result: Int = sum(a, b);

	println("Result : $result" );

	// Expected Result: 2147483758;
	// Result : -2147483538
	// Result : -2147483648
	// Max of Int : 2147483647
	// Min of Int : -2147483648	
}

