
package learnJava;

class Employee {
	// Instance Member Variable
	//		Binded With Instance i.e Can Be Accessed Using Instance
	private int id;	// Member Variables
	private String name;

	// Type/Class Member Variable
	//		Binded With Type/Class i.e Can Be Accessed Using Type/Class
	public static int typeVariable;
	
	// Constructor is Special Member Function
	public Employee(int id, String name) { 
		this.id = id;
		this.name = name;
	}

	// Instance Member Functions
	//		Binded With Instance i.e Can Be Accessed Using Instance
	public int getID() 		{ return id; } // Member Functions
	public String getName() { return name; }

	// Type/Class Member Functions
	//		Binded With Type/Class i.e Can Be Accessed Using Type/Class
	public static void work() { System.out.println("\nEmployee Working!..."); }
}

public class JavaClasses {
	public static void playWithEmployee() {
		Employee gabbar = new Employee(101, "Gabbar Singh");
		Employee sambha = new Employee(101, "Samba Singh");

		System.out.println("Gabbar Details: " + gabbar.getID() + "," + gabbar.getName());
		System.out.println("Sambha Details: " + sambha.getID() + "," + sambha.getName());

		// Type/Class Members Accessed Using Type/Class
		//		i.e. Without Creating Instance
		Employee.work();
		System.out.println("TypeVariable Value: " + Employee.typeVariable);
	}

	public static void main(String[] args) {
		System.out.println("\nFunction : playWithEmployee");
		playWithEmployee();

		//JavaClasses.java:31: error: non-static method playWithEmployee() cannot be referenced from a static context
	}
}







// import java.util.Random;
// class RandomNumbers {
// 	private static Random generator = new Random();
// 	public static int nextInt(int low, int high) {

// 	}
// }
	// public static void playWithRandomNumbers() {

	// }
		// System.out.println("\nFunction : playWithRandomNumbers")
		// playWithRandomNumbers()
