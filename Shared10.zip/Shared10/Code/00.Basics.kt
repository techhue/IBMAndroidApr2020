
package learnKotlin;

import java.util.Random;
import java.util.TreeMap;

/*
	Kotlin Language
	____________________________________________________
	1. It's Case Sensitive Language
	2. It's Consise and Beautiful Langauage
*/

// Function With No Arguments
fun helloWorld(): Unit {
	println("Hello World!")
}

fun playWithHelloWorld() {
	val result = helloWorld()
	println("Hello Result : $result")
}

// fun max(a: Int, b: Int) { // Gives Error
// 01.Basics.kt:27:20: error: type mismatch: inferred type is Int but Unit was expected
// 	return if (a > b) a else b
//                    ^
// 01.Basics.kt:27:27: error: type mismatch: inferred type is Int but Unit was expected
// 	return if (a > b) a else b

// Function With 2 Int Arguments
	// Return Type Is Int

fun max(a: Int, b: Int): Int {
	return if (a > b) a else b
}

// Person Class With Two Properties [Name and isMarried]
class Person(
	// val means Immutable: name is Constant
	val name: String,
	// var means Variable: isMarried can be changed
	var isMarried: Boolean
)

fun playWithPersonProperties() {
	// Created person Object of Type Person
	val person = Person("Rajnikant", true)
	// Accessing Person Properties

	// person.name = "Kamal Hassan" // Error: Unmodifiable
	person.isMarried = false

	println(person.name)
	println(person.isMarried)
}

// Mutability and Immutability in Kotlin
fun playWithMutability() {
	val notChangableValue = 100 // Immutable : Unmodifiable
	var changableValue = 1000	// Mutable   : Modifiable

//    notChangableValue = 9000 // Error: Val cannot be reassigned
	println(changableValue)
	changableValue = 9090
	println(notChangableValue)
	println(changableValue)
}

// Rectangle Class Have Three Properties
// 		1. Two Stored Properties
//			It Will Stored and Read From There
//			Int Properties height and width
// 		2. One Computed Property
//			It Will Be Calcualted Rather Than Stored
//			Boolean Property isSquare is Computed Property

class Rectangle(
	val height: Int,	// Stored Property
	val width: Int		// Stored Property
){
	val isSquare: Boolean // Computed Property
		// Getter Will Called On Access Of This Property
		get() { 
			return height == width
		}
	val area: Int 
		get() {
			return width * height
		}
}

fun playWithRectangle() {
	// rectangle1 is Object of Rectangle Type
	// 		Will Allocate Storage/Memory
	//			Two Properties height and width
	//		But Will Not Allocate Memory for isSquare
	//			This Will Calculated When You Access It
	//				At Runtime

	val rectangle1 = Rectangle(20, 40)
	println(rectangle1.width)
	println(rectangle1.height)
	// Getting Calculated Whenever You Access isSquare
	println(rectangle1.isSquare)
	println(rectangle1.area)
	
	// Above Line Will Get Translated To Below Line
	// By Compiler
	// println( rectangle1.get_isSquare() )

	val rectangle2 = Rectangle(100, 100)
	println(rectangle2.width)
	println(rectangle2.height)
	println(rectangle2.isSquare)
	println(rectangle2.area)
}

// import java.util.Random;

// Function Returning Rectangle Type Object
fun createRandomRectangle() : Rectangle {
	val random = Random()
	val rectangle = Rectangle(random.nextInt(), random.nextInt())
	return rectangle
}

fun playWithRandomRectangle() {
	println("\nFunction: createRandomeRectangle")
	val rect1 = createRandomRectangle()
	
	// String Formatting: Variable Values Get Substituted
	println("Width: ${rect1.width} Height: ${rect1.height}")

	println("\nFunction: createRandomeRectangle")
	val rect2 = createRandomRectangle()
	
	// String Formatting: Variable Values Get Substituted
	println("Width: ${rect2.width} Height: ${rect2.height}")
}

enum class PrimaryColor {
	RED, GREEN, BLUE
}

fun playWithPrimaryColors() {
	val sky = PrimaryColor.BLUE
	val grass = PrimaryColor.GREEN
	val apple = PrimaryColor.RED

	println("Apple Color: $apple, Sky Color: $sky, Grass Color: $grass")
}

// Enum Classes Are Used For Creating Enum Constants
// Following Code 
// 		Creates RED, GREEN and BLUE Constants of Color	Type
//		Generally Constants Are Written In CAPITAL Letters	

enum class Color {
	RED, GREEN, BLUE, ORANGE
}

// error: 'when' expression must be exhaustive, 
//		MUST Cover All The Cases
// 			add necessary 'ORANGE' branch 
//			or 'else' branch instead

// Function Takes One Argument of Color Type
// 		And Return Value of String Type

fun playWithChoices(color: Color) : String {

	// When Expression is Similiar To Switch Statement
	return	when(color) {
		Color.RED -> "Apple, Tomato, Chilli Are Red Color"
		Color.GREEN -> "Grass, Tree Leaves Are Green Color"
		Color.BLUE -> "Sky and Water Are Blue Color"
		Color.ORANGE -> "Orange is First Color In India Flag"
			// Style 2 : Kotlin Style Programming
		// else -> "Not Primary Color"  // It's Default Case
			// Style 1 : Java Style Programming
	}
}

fun convertColorToString(color: Color): String {
	return when(color) {
		Color.RED -> "Red Color"
		Color.GREEN -> "Green Color"
		Color.BLUE -> "Blue Color"
		Color.ORANGE -> "Orange Color"
	}
}

fun playWithColorToString() {
	println(convertColorToString(Color.RED))
	println(convertColorToString(Color.GREEN))
	println(convertColorToString(Color.BLUE))
	println(convertColorToString(Color.ORANGE))
}

fun playWithKotlinTypes() {
	// Compiler Will Try To Inference Type : Kotlin Style
	// 		If Not Specified Explicitly
	// Type In Kotlin
	// _______________________________________________________
	// 	1. Type Inferencing 
	// 			Implicitly is Default
	// 			Can Specify Explicitly Also
	// 	2. Type Binding
	// 	3. Value Storage
	val some 	= 10  			// Type : 
	val hello 	= "Vankaaam!" 	// Type : 
	val ding 	= 90.10 		// Type : 
	val dong 	= 'A' 			// Type : 

	println(some)
	println(hello)
	println(ding)
	println(dong)

	// Explicit Types Assigned
	// Java/C/C++ Style
	val some1: Int 			= 10  			
	val hello1: String 		= "Vankaaam!" 	
	val ding1: Double 		= 90.10 		
	val dong1: Char 	 	= 'A' 			

	println(some1)
	println(hello1)
	println(ding1)
	println(dong1)

	val ding3: Float 	= 90.10F
	println(ding3)
	// 	1. Type Inferenced Will Be Double
	// 	2. Type Binding Done Explicitly Float
	//	3. Value Storage In ding3
	
	// NOTE: In case Java/C/C++ 
		// Type Converstion of Value From Double To Float Will Happen
			// float ding3 	= 90.10
}

// Default Return Type of Function is Unit Type
// Default Return Value of Function is Unit Value
fun playWithUnitType() {
	// Unit is Value of Unit Type
	val unitValue: Unit = Unit 
	print(unitValue)
}

// Enum Types Can Have Schema
//	This Colour Type Has Three Components 
//		(RedComponent, GreenComponent, BlueComponent)
//		These Components Can Be Accessed Using Colour Values

enum class Colour(var r: Int, val g: Int, val b: Int) {
	RED(255,0, 0), GREEN(0, 255, 0), BLUE(0, 0, 255),
	ORANGE(200, 100, 100), VIOLET(200, 0, 200), YELLOW(0, 200, 200),
	INDIGO(100, 100, 100)
	;

	// Member Function
	fun rgb(): Int {
		return (r * 256 + g) * 256 + b
	}
}

fun playWithColours() {
	// Accessing RED Colour
	println("Colour : ${Colour.RED}")
	println(Colour.RED.rgb())

	// Accessing Red Component of RED Colour
	println("Red Component 		: ${Colour.RED.r}" ) 
	
	// Accessing Green Component of RED Colour
	println("Green Component 	: ${Colour.RED.g}") 
	
	// Accessing Blue Component of RED Colour
	println("Blue Component 	: ${Colour.RED.b}") 
	
	println(Colour.BLUE)
	println(Colour.BLUE.rgb())
	println(Colour.BLUE.r)
	println(Colour.BLUE.g)
	println(Colour.BLUE.b)	

	println(Colour.ORANGE)
	println(Colour.ORANGE.rgb())

	println(Colour.VIOLET)
	println(Colour.VIOLET.rgb())
}

fun getColorNature(colour: Colour): String {
	return when(colour) {
		Colour.RED, Colour.ORANGE, Colour.YELLOW 	-> "Warm Colour"
		Colour.GREEN 				-> "Cold Colour"
		Colour.BLUE, Colour.VIOLET, Colour.INDIGO 	-> "Neutral Colour"
	}
}

fun playWithColoursNature() {
	println(getColorNature(Colour.RED))
	println(getColorNature(Colour.GREEN))
	println(getColorNature(Colour.VIOLET))
	println(getColorNature(Colour.BLUE))
	println(getColorNature(Colour.ORANGE))
}

fun mixColours(c1: Colour, c2: Colour): Colour {
	return when( setOf(c1, c2) ) {
		setOf(Colour.RED, Colour.BLUE) 		-> Colour.VIOLET
		setOf(Colour.YELLOW, Colour.BLUE) 	-> Colour.INDIGO
		else -> throw Exception("Unknown Color Combination")
	}

}

fun playWithColourMixing() {
	println(mixColours(Colour.RED, Colour.BLUE))
	println(mixColours(Colour.BLUE, Colour.RED))
	println(mixColours(Colour.BLUE, Colour.YELLOW))
	println(mixColours(Colour.YELLOW, Colour.BLUE))
	// Function: playWithColourMixing
	// VIOLET
	// VIOLET
	// INDIGO
	// INDIGO
}

fun fizzBuzz(i: Int) : String {
	return when {
		i % 15 	== 0 -> "FizzBuzz"
		i % 3	== 0 -> "Fizz"
		i % 5   == 0 -> "Buzz"
		else -> "Value: $i"
	}
}

// .. Is Range Operator
//	1..100 means 1, 2, 3, 4, 5, .... 100

fun playWithFizzBuzz() {
	// For Loop with Step of +1
	// i will take values viz 1, 2, 3, 4...
	for (i in 1..100) {
		println( fizzBuzz(i) )
	}
}

fun playWithFizzBuzzReverse() {
	// For Loop with Step of -2
	// i will take values viz 100, 98, 96, 94...
	for (i in 100 downTo 1 step 2){
		println( fizzBuzz(i) )
	}
}

fun sum(a: Int, b: Int) : Int {
	return a + b
}

// In Kotlin You Can Assign Value To The Function
// Above Sum Function Can Be Written Like This Also
fun add(a: Int, b: Int) = a + b

fun playWithSumAndAdd() {
	val result1 = sum(10, 20)
	println("\nResult : $result1")

	val result2 = add(10, 20)
	println("\nResult : $result2")
}


// In Operator is Membership Check Operator
fun isLetter(c: Char) 	= c in 'a'..'z' || c in 'A'..'Z'
fun isDigit(c: Char)	= c in '0'..'9'
fun isNotDigit(c: Char)	= c !in '0'..'9'

fun playWithInOperator() {
	println( isLetter('A'))
	println( isLetter('M'))
	println( isLetter('0'))
	println( isLetter('t'))
	println( isLetter('u'))
	println( isLetter('$'))

	println( isDigit('1'))
	println( isDigit('7'))
	println( isDigit('U'))
	println( isNotDigit('U'))
	println( isNotDigit('s'))
	println( isNotDigit('7'))
}

fun recognizeCharacter(c: Char) = when (c) {
	in '0'..'9'	-> "It's Digit"
	in 'a'..'z', in 'A'..'Z' -> "It's A English Letter"
	else -> "I don't know what is it..."
}

fun playWithRecognizeCharacter() {
	println( recognizeCharacter('A') )
	println( recognizeCharacter('a') )
	println( recognizeCharacter('Z') )
	println( recognizeCharacter('0') )
	println( recognizeCharacter('$') )
	println( recognizeCharacter('#') )
}

//  import java.util.TreeMap;
fun playWithMaps() {
									// Key, Value
	val binaryRepresentation = TreeMap<Char, String>()

	for(c in '0'..'9') {
		val binary = Integer.toBinaryString(c.toInt())
		
		// Storing Binary Representation of each Char
		// Key is Char and Value is Binary Representation
		binaryRepresentation[c] = binary
	}

	for(c in 'A'..'F') {
		val binary = Integer.toBinaryString(c.toInt())

		// Storing Binary Representation of each Char
		// Key is Char and Value is Binary Representation
		binaryRepresentation[c] = binary
	}

	// In Python
	// for key, value in d.items():
	for( (letter, binary) in binaryRepresentation ) {
		println("Binary Representation For Char: $letter = $binary")
	}
}

// interface Expr 
// class 



fun main() {
	println("\nFunction: playWithMaps")
	playWithMaps()

	println("\nFunction: playWithInOperator")
	playWithInOperator()

	println("\nFunction: playWithRecognizeCharacter")
	playWithRecognizeCharacter()

	println("\nFunction: playWithSumAndAdd")
	playWithSumAndAdd()

	println("\nFunction: playWithFizzBuzz")	
	playWithFizzBuzz()

	println("\nFunction: playWithFizzBuzzReverse")	
	playWithFizzBuzzReverse()

	println("\nFunction: playWithColourMixing")
	playWithColourMixing()

	println("\nFunction: playWithColoursNature")
	playWithColoursNature()

	println("\nFunction: playWithColours")
	playWithColours()

	println("\nFunction: playWithUnitType")
	playWithUnitType()

	println("\nFunction: playWithKotlinTypes")
	playWithKotlinTypes()

	println("\nFunction: helloWorld")
	playWithHelloWorld()

	println("\nFunction: max")
	println(max(-10, 90))

	println("\nFunction: playWithPersonProperties")
	playWithPersonProperties()

	println("\nFunction: playWithMutability")
	playWithMutability()

	println("\nFunction: playWithRectangle")
	playWithRectangle()

	println("\nFunction: playWithRandomRectangle")
	playWithRandomRectangle()

	println("\nFunction: playWithPrimaryColors")
	playWithPrimaryColors()

	println("\nFunction: playWithChoices")
	println(playWithChoices(Color.RED))
   	println(playWithChoices(Color.BLUE))

	println("\nFunction: playWithColorToString")
	playWithColorToString()
}

// 0. Write Above Code In Your Favorite Editor
// 1. Saved In File: Hello.kt
		// Kotlin File Extension Is: .kt
// 2. Copy Code In Online Compiler Window
// 3. Run Code

// +++++++++++++++++++++++++++++++++++++++++++++++++++++++
// 			AFTER COMPLETING ABOVE STEPS
// 			Type DONE in Chat Window 
// +++++++++++++++++++++++++++++++++++++++++++++++++++++++
